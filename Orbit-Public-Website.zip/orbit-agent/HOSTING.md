# Publish the full Orbit website — without an external AI API

**Status:** the app and deployment package are built. A public hosting account/Codespace has **not** been created by the assistant. No public URL has been invented. Arena's protected preview is not public hosting.

Orbit is a **single-owner** website: the homepage is public; chat, files, knowledge, screen streaming, and desktop control require owner login in deployment mode. This is not a multi-tenant service with isolated computers for different users.

## Easiest free, usage-limited public demo: GitHub Codespaces

A personal GitHub Free account currently includes **120 core-hours and 15 GB-month storage**. A 2-core machine consumes two core-hours per actual hour, so the included compute is approximately **60 running hours/month**, not 24/7 free hosting. Storage also counts when stopped. Without a payment method, use is blocked when the quota is exhausted; with a payment method, overages can be billed. Review your billing/budget settings first. Do not add a payment method just to follow this guide.

Official billing rules:
https://docs.github.com/en/billing/concepts/product-billing/github-codespaces

Public forwarded ports are supported and have a real shareable URL while the Codespace/service is running. Idle timeouts, quota exhaustion, deletion, and stopping can make it unavailable. **This is a demo/development hosting route, not a permanent production website.**

Official port-sharing instructions:
https://docs.github.com/en/codespaces/developing-in-a-codespace/forwarding-ports-in-your-codespace

### Steps you do in your own account

1. Sign in to your personal GitHub account. Create a repository, such as `orbit-ai`. The assistant has not created this repository. Start private if you want to keep the source private.
2. Upload the **contents of the deployment ZIP's `orbit-agent/` folder** to the repository root. Include `.devcontainer/` and `.gitignore`. **Do not upload personal `workspace/`, `.orbit-owner.env`, cache, logs, or credentials.** The supplied ZIP excludes them.
3. Choose **Code → Codespaces → Create codespace**. Use the 2-core configuration to conserve your included usage. Initial installation may take several minutes.
4. In the Codespace terminal, after setup finishes:

   ```bash
   .venv/bin/python create_auth.py
   ```

   Choose your own long passphrase. Enter it only in that terminal. It is not echoed, stored in plaintext, committed, or sent to chat. The resulting ignored `.orbit-owner.env` has mode 0600.
5. Start the password-protected service:

   ```bash
   bash public_start.sh
   ```

   Keep this terminal running. `public_start.sh` refuses to start without a valid password hash and signing secret. Never use the ordinary development entrypoint for public exposure.
6. In the Codespace **PORTS** panel, find **3000**, then set **Port Visibility → Public**. Keep the backend port protocol as **HTTP**; the external forwarded address is HTTPS. Do not expose the internal model port 8089, X display, SSH/debug ports, or other services.
7. Copy the **actual forwarded address** from the PORTS panel. That is your website link. It usually has the form `https://<actual-codespace-name>-3000.app.github.dev/`, but you must copy your real address—this format is not a deployed link.
8. Open the link: the homepage is public. **Open workspace** goes to the owner login. Only share the passphrase with someone you intentionally trust with the whole computer and your files.

**Restart:** open the same Codespace, run `bash public_start.sh`, and use its actual port URL. Source and workspace data in the Codespace can survive stop/resume, but deletion/rebuild semantics vary; make backups. Do not rely on this as permanent storage.

**Password change:** run `create_auth.py` again, confirm replacement, then restart the service. Existing cookies become invalid. Sessions otherwise expire after eight hours.

## Other free hosts: check current rules, not old tutorials

- Hugging Face's current official documentation says creating **Docker/Gradio compute Spaces requires a paid plan** (with a specific personal ZeroGPU Gradio exception). CPU Basic having no hourly charge is **not** the same as an unrestricted free Docker account. This package therefore does not promise a free Docker Space.
  https://huggingface.co/docs/hub/spaces-overview
- Oracle's official Always Free documentation, updated June 12, 2026, currently lists an Ampere A1 pool equivalent to **2 OCPUs / 12 GB RAM**, not the older 4/24 figures repeated by blogs. Capacity may be unavailable and idle instances may be reclaimed. Signup/account verification is your responsibility. Do not accidentally choose billable resources.
  https://docs.oracle.com/en-us/iaas/Content/FreeTier/freetier_topic-Always_Free_Resources.htm

The provided Dockerfile builds a pinned CPU llama.cpp runtime from source for the build architecture, so it can be adapted to x86-64 or ARM64 hosts. **ARM/Docker deployment has not been executed in this Arena session.** It is a configuration package, not a claim that a VM/account was created or tested.

## Optional own Linux server with HTTPS

The supplied `compose.yaml` + Caddyfile are for a server you own. A real DNS name must point to it, and ports 80/443 must be allowed. The app stays on an internal Docker network; do not expose port 3000 directly.

1. Install Docker/Compose using the host's official instructions.
2. Generate owner credentials interactively with `create_auth.py` (locally before copying the private env file, or using a trusted Python environment on the host).
3. Set `ORBIT_DOMAIN` in your own shell to the domain you control.
4. Build/start:

   ```bash
   docker compose up --build -d
   ```

5. Use your real HTTPS domain. Check the logs, backups, resource limits, and certificate issuance before inviting anyone.

Owner configuration must remain private. Caddy storage and Orbit workspace/model cache use Docker volumes. Back up `workspace/` and the SQLite database. No new foundation model was trained; inference stays on your host with existing Qwen weights.

## Boundaries

- A password gate is not hardened VM isolation. This remains a single-owner computer; manual takeover includes a broad shell. Do not share access with strangers or sign into sensitive accounts.
- Deployment mode protects private HTTP endpoints and WebSocket streaming. Native desktop launchers use a separate ephemeral local token, restricted to the loopback desktop bridge/artifact paths.
- HTTPS is required for deployment cookies. Do not set `ORBIT_COOKIE_SECURE=0` on a public host; that setting is for local authentication tests only.
- The assistant cannot sign up for accounts, verify identity/card details, acquire hosting capacity, or give you a working public link without an actual hosting destination. No account, server, paid resource, or purchase has been created here.
