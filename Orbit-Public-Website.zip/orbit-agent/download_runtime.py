#!/usr/bin/env python3
"""Verified local-model bootstrap. Downloads only into the disposable cache.
The saved project contains this small manifest/code, never the model weights.
"""
import hashlib
import json
import os
from pathlib import Path
import requests
import tarfile
import fcntl

ROOT = Path(__file__).resolve().parent
CACHE = Path(os.environ.get('ORBIT_CACHE', str(Path.home() / '.cache/orbit')))
TAG = 'b11541'


def profile():
    manifest = json.loads((ROOT / 'models.json').read_text())
    key = os.environ.get('ORBIT_MODEL', manifest['default'])
    if key not in manifest['profiles']:
        raise ValueError(f'Unknown model profile: {key}')
    result = dict(manifest['profiles'][key])
    result['id'] = key
    result['vision'] = bool(result.get('vision_file')) and os.environ.get('ORBIT_VISION', '1') != '0'
    result['path'] = str(CACHE / 'models' / result['file'])
    if result['vision']:
        result['vision_path'] = str(CACHE / 'models' / result['vision_file'])
    return result


def download(url, path, expected=None, progress=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    print(f'Downloading {path.name} to temporary cache…', flush=True)
    temp = path.with_name(path.name + '.part')
    n = 0
    with requests.get(url, stream=True, timeout=(30, 120)) as r:
        r.raise_for_status()
        total = int(r.headers.get('content-length', 0)) or expected or 0
        with temp.open('wb') as out:
            for chunk in r.iter_content(1024 * 1024):
                out.write(chunk)
                n += len(chunk)
                if progress:
                    progress(path.name, n, total)
    if expected and n != expected:
        temp.unlink(missing_ok=True)
        raise RuntimeError(f'Incomplete model download: {path.name}')
    temp.rename(path)


def verified(path, checksum, expected_size=None):
    if not path.exists() or (expected_size and path.stat().st_size != expected_size):
        return False
    stamp = path.with_name(path.name + '.verified.json')
    key = {'sha256': checksum, 'size': path.stat().st_size, 'mtime': path.stat().st_mtime_ns}
    try:
        if json.loads(stamp.read_text()) == key:
            return True
    except (OSError, ValueError):
        pass
    digest = hashlib.sha256()
    with path.open('rb') as src:
        for chunk in iter(lambda: src.read(1024 * 1024), b''):
            digest.update(chunk)
    if digest.hexdigest() != checksum:
        return False
    stamp.write_text(json.dumps(key))
    return True


def ensure_runtime(progress=None):
    CACHE.mkdir(parents=True, exist_ok=True)
    with (CACHE / 'bootstrap.lock').open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        custom = os.environ.get('ORBIT_LLAMA_SERVER')
        if custom and (not Path(custom).is_file() or not os.access(custom, os.X_OK)):
            raise ValueError('ORBIT_LLAMA_SERVER must point to an existing executable on your own host')
        if not custom and not list((CACHE / 'runtime').rglob('llama-server')):
            archive = CACHE / 'runtime' / 'llama.tar.gz'
            download(f'https://github.com/ggml-org/llama.cpp/releases/download/{TAG}/llama-{TAG}-bin-ubuntu-x64.tar.gz', archive, progress=progress)
            with tarfile.open(archive) as tar:
                tar.extractall(archive.parent, filter='data')
            archive.unlink()
        p = profile()
        pairs = [(p['file'], p['sha256'], p['size'])]
        if p['vision']:
            pairs.append((p['vision_file'], p['vision_sha256'], p['vision_size']))
        for filename, sha, size in pairs:
            dest = CACHE / 'models' / filename
            if not verified(dest, sha, size):
                download(f'https://huggingface.co/{p["repo"]}/resolve/main/{filename}?download=true', dest, size, progress)
                if not verified(dest, sha, size):
                    dest.unlink(missing_ok=True)
                    raise RuntimeError(f'Model checksum mismatch: {filename}')
        print(f'Local AI ready: {p["name"]} {p["quant"]}' + (' + vision' if p['vision'] else '') + '. Checksums verified; no external AI API.', flush=True)
        return p


if __name__ == '__main__':
    ensure_runtime()
