#!/usr/bin/env bash
# Password-protected entrypoint for your own HTTPS host / Codespace.
set -euo pipefail
cd "$(dirname "$0")"
if [[ -f .orbit-owner.env ]]; then
  set -a
  source .orbit-owner.env
  set +a
fi
export ORBIT_AUTH_REQUIRED=1
export ORBIT_COOKIE_SECURE=1
PY=python3
if [[ -x .venv/bin/python ]]; then PY=.venv/bin/python; fi
"$PY" - <<'PY'
from app import auth
if not auth.configured():
    raise SystemExit('Owner login is not configured. Run python create_auth.py in your host terminal first. Do not expose the app publicly without it.')
PY
exec bash start.sh
