"""Verifies real web-to-desktop clicks, typing, window dragging, and key controls.
Uses only a temporary owned agent/HTML file; does not edit user documents.
"""
import asyncio
import json
import shutil
import subprocess
import sys
import uuid
from pathlib import Path
import requests
from playwright.async_api import async_playwright

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from app import store
BASE = 'http://127.0.0.1:3000'


def api(path, method='GET', data=None):
    r = requests.request(method, BASE + path, json=data, timeout=30)
    r.raise_for_status()
    return r.json()


def chrome_geometry():
    text = subprocess.check_output(['wmctrl', '-l', '-G'], env={**__import__('os').environ, 'DISPLAY': ':97'}).decode()
    row = next(x for x in text.splitlines() if 'Chromium' in x)
    fields = row.split()
    return [int(x) for x in fields[2:6]]


async def run():
    before = api('/api/state')
    assert not before['runtime']['manual'] and not before['runtime']['active_task']
    original = before['selected']
    aid = api('/api/agents', 'POST', {'name': 'Control ' + uuid.uuid4().hex[:6], 'role': 'Temporary owned input verifier.'})['id']
    b = None
    try:
        html = '<!doctype html><html><head><title>Control check</title></head><body style="margin:0;padding:20px;background:#eef2e8;font-family:sans-serif"><h1 style="margin:0 0 24px;font-size:26px;line-height:32px">Real desktop input check</h1><input style="width:400px;height:55px;font-size:30px" oninput="location.hash=this.value" aria-label="Native input"><p>This is an owned verification file.</p></body></html>'
        api('/api/file', 'POST', {'agent': aid, 'path': 'control.html', 'content': html})
        api('/api/file/preview', 'POST', {'agent': aid, 'path': 'control.html'})
        async with async_playwright() as p:
            b = await p.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox', '--disable-dev-shm-usage', '--disable-gpu'])
            page = await b.new_page(viewport={'width':1440, 'height':1000})
            await page.add_init_script('sessionStorage.setItem("orbit-agent", ' + json.dumps(aid) + ')')
            errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
            await page.goto(BASE+'/app')
            await page.wait_for_function('typeof state !== "undefined" && state.runtime.engine_ready')
            await page.wait_for_function('document.getElementById("screen-image").naturalWidth===1024')
            await page.locator('#take-control').click()
            await page.wait_for_function('state.runtime.manual')
            box = await page.locator('#screen-image').bounding_box()
            def pt(x,y): return (box['x']+x/1024*box['width'],box['y']+y/640*box['height'])
            await page.mouse.click(*pt(160,253))
            await page.keyboard.type('orbit-proof',delay=65)
            await page.wait_for_function('state.runtime.browser_url.endsWith("#orbit-proof")',timeout=20000)
            old = chrome_geometry()
            await page.mouse.move(*pt(600,84));await page.mouse.down()
            await page.wait_for_timeout(180)
            for step in range(1, 5):
                await page.mouse.move(*pt(600 + step * 10, 84 + step * 5))
                await page.wait_for_timeout(120)
            await page.mouse.up()
            await page.wait_for_timeout(650)
            new = chrome_geometry()
            assert new[0] - old[0] >= 25 and new[1] - old[1] >= 10, (old,new)
            await page.keyboard.press('Control+l')
            await page.locator('#take-control').click()
            await page.wait_for_function('!state.runtime.manual')
            assert not errors, errors
            result={'passed':True,'typed_value':'orbit-proof','window_before':old,'window_after':new,'checks':['real pointer click','real keyboard typing','fragment confirmed by actual browser URL','real window drag','keyboard shortcut','return control'],'js_errors':errors}
            (ROOT / 'verification/control-v2.json').write_text(json.dumps(result,indent=2))
            print(json.dumps(result,indent=2))
            await b.close();b=None
    finally:
        if b:
            try:await b.close()
            except Exception:pass
        api('/api/control','POST',{'active':False})
        api('/api/desktop/launch','POST',{'app':'browser','agent':original})
        api('/api/browser/home','POST',{})
        with store.connect() as db:
            for table in ['messages','events','tasks']:
                db.execute(f'DELETE FROM {table} WHERE agent=?',(aid,))
            db.execute('DELETE FROM agents WHERE id=?',(aid,))
        shutil.rmtree(store.WORKSPACE / aid,ignore_errors=True)


if __name__ == '__main__':
    asyncio.run(run())
