"""Real local-model retrieval + feedback regression. Own fixtures only."""
import io
import json
import shutil
import sys
import time
import uuid
import zipfile
from pathlib import Path
import requests

ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
from app import store, knowledge, storage
BASE='http://127.0.0.1:3000'
http=requests.Session()


def api(path,method='GET',**kwargs):
    r=http.request(method,BASE+path,timeout=40,**kwargs);r.raise_for_status();return r.json()


def ask(aid,q,natural=False):
    t=api('/api/tasks','POST',json={'agent':aid,'prompt':q if natural else 'Use my knowledge library to answer: '+q})
    deadline=time.monotonic()+90
    while time.monotonic()<deadline:
        s=api('/api/state',params={'agent':aid});row=next(x for x in s['tasks'] if x['id']==t['id'])
        if row['state'] in {'done','error','stopped'}:
            assert row['state']=='done',row
            return row['result'],s
        time.sleep(.5)
    raise TimeoutError(q)


def run():
    before=api('/api/state');assert not before['runtime']['manual'] and not before['runtime']['active_task']
    original=before['selected'];owned=[];start=time.monotonic();result={'passed':False}
    try:
        a=api('/api/agents','POST',json={'name':'Library check '+uuid.uuid4().hex[:5],'role':'An owned local knowledge verifier.'})['id'];owned.append(a)
        b=api('/api/agents','POST',json={'name':'Scope check '+uuid.uuid4().hex[:5],'role':'An owned isolation verifier.'})['id'];owned.append(b)
        text=b'The MapleTrail launch date is November 18, 2026.\nThe MapleTrail support email is crew@example.invalid.\nThe project has three review stages.\n'
        r=http.post(BASE+'/api/knowledge/upload',data={'agent':a},files={'file':('project-notes.md',text,'text/markdown')},timeout=20);r.raise_for_status();doc=r.json()
        assert doc['chunks']>0
        assert http.post(BASE+'/api/knowledge/upload',data={'agent':a},files={'file':('same.md',text)},timeout=20).status_code==400
        hits=api('/api/knowledge/search',params={'agent':a,'q':'MapleTrail launch date'})['hits'];assert hits and 'November 18, 2026' in hits[0]['content']
        assert not api('/api/knowledge/search',params={'agent':b,'q':'MapleTrail launch date'})['hits']
        answer,s=ask(a,'What is the MapleTrail launch date?');assert 'November 18, 2026' in answer and '[K1]' in answer,answer
        natural_answer,_=ask(a,'What is the MapleTrail launch date?',natural=True);assert 'November 18, 2026' in natural_answer
        result['natural_question_answer']=natural_answer
        result['grounded_answer']=answer;print('PASS: real-model answer from uploaded fact with citation',flush=True)
        assert any(e['kind']=='knowledge' and e['state']=='done' for e in s['events'])
        message=s['messages'][-1]['id']
        f=api('/api/feedback','POST',json={'agent':a,'message':message,'score':-1,'correction':'Keep the date with its source citation.'});assert f['correction']
        assert http.post(BASE+'/api/feedback',json={'agent':b,'message':message,'score':1},timeout=10).status_code==400
        export=http.get(BASE+'/api/feedback/export',params={'agent':a},timeout=10);export.raise_for_status();row=json.loads(export.text.strip());assert row['answer']==answer and row['score']==-1
        assert api('/api/knowledge',params={'agent':a})['summary']['needs_work']==1
        print('PASS: local feedback, complete export, agent ownership',flush=True)
        missing,_=ask(a,'What is the unicorn spacecraft registration code?');assert 'couldn’t find' in missing or 'not a supported answer' in missing,missing
        result['unsupported_answer']=missing
        other,_=ask(b,'What is the MapleTrail launch date?');assert 'couldn’t find' in other,other
        # Simulate an explicit manual desktop edit to the owned fixture's raw copy.
        source=store.safe_path(a,doc['path']);source.write_text('Changed source content. The old index must not be treated as current.')
        stale,_=ask(a,'What is the MapleTrail launch date?');assert 'November 18, 2026' not in stale and 'couldn’t find' in stale,stale
        source.write_bytes(text)
        print('PASS: unsupported questions, per-agent isolation, stale-source detection',flush=True)
        assert http.post(BASE+'/api/file',json={'agent':a,'path':doc['path'],'content':'bad'},timeout=10).status_code==400
        assert http.delete(BASE+'/api/file',json={'agent':a,'path':doc['path']},timeout=10).status_code==400
        assert http.post(BASE+'/api/feedback',json={'agent':a,'message':message,'score':1},headers={'Origin':'https://unrelated.example'},timeout=10).status_code==403
        backup=http.get(BASE+'/api/agents/'+a+'/export',timeout=25);backup.raise_for_status()
        with zipfile.ZipFile(io.BytesIO(backup.content)) as z:
            assert 'knowledge-documents.json' in z.namelist() and 'feedback.ndjson' in z.namelist()
            assert 'files/'+doc['path'] in z.namelist()
        api('/api/knowledge/'+doc['id'],'DELETE',params={'agent':a})
        assert not source.exists() and not api('/api/knowledge/search',params={'agent':a,'q':'MapleTrail'})['hits']
        result.update(passed=True,seconds=round(time.monotonic()-start,2),checks=['local FTS5 indexing/search','real local-model source selection','source citations','unsupported-answer refusal','agent isolation','source integrity','feedback persistence/export','source edit guards','same-origin guard','complete agent backup','explicit document removal'])
        print(json.dumps(result,indent=2))
    finally:
        for aid in owned:
            with store.connect() as db:
                pending = db.execute('SELECT id FROM tasks WHERE agent=? AND state IN (?,?,?,?)', (aid,'queued','running','paused','waiting')).fetchall()
            for t in pending:
                try:api('/api/tasks/'+t['id']+'/stop','POST',json={})
                except Exception:pass
        time.sleep(.25)
        for aid in owned:
            with store.connect() as db:
                db.execute('DELETE FROM knowledge_chunks WHERE agent=?',(aid,))
                for table in ['knowledge_documents','answer_feedback','messages','events','tasks']:
                    db.execute(f'DELETE FROM {table} WHERE agent=?',(aid,))
                db.execute('DELETE FROM agents WHERE id=?',(aid,))
            shutil.rmtree(store.WORKSPACE/aid,ignore_errors=True)
        storage.written()
        try:api('/api/desktop/launch','POST',json={'app':'browser','agent':original})
        except Exception:pass
        (ROOT/'verification/knowledge-v3.json').write_text(json.dumps(result,indent=2))


if __name__=='__main__':run()
