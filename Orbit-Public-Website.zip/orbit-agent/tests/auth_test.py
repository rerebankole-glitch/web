"""Authentication isolation tests. Dummy test credentials only; no real password.
ASGI clients do not boot another model/server or modify user records.
"""
import asyncio
import json
import secrets
import sys
import time
from pathlib import Path

import httpx
from fastapi.testclient import TestClient
from starlette.websockets import WebSocketDisconnect

ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
from app import auth

auth.REQUIRED=True
auth.PASSWORD_HASH=auth.password_hash('Dummy-test-passphrase-not-a-user-secret')
auth.SESSION_SECRET=secrets.token_urlsafe(48)
from app.server import app


async def check():
    checks=[]
    transport=httpx.ASGITransport(app=app,client=('203.0.113.7',12345))
    async with httpx.AsyncClient(transport=transport,base_url='https://owner.example',follow_redirects=False) as c:
        assert (await c.get('/')).status_code==200
        assert (await c.get('/guide')).status_code==200
        assert (await c.get('/login')).status_code==200
        assert (await c.get('/api/site')).status_code==200
        assert (await c.get('/app')).status_code==303
        for path in ['/api/state','/api/screen','/api/health','/api/activity','/api/storage']:
            assert (await c.get(path)).status_code==401,path
        assert (await c.post('/api/input',json={'kind':'click'})).status_code==401
        checks.append('public homepage; private workspace/APIs denied without login')
        assert (await c.post('/api/auth/login',json={'password':'wrong'})).status_code==401
        assert (await c.post('/api/auth/login',json={'password':'Dummy-test-passphrase-not-a-user-secret'},headers={'Origin':'https://unrelated.example'})).status_code==403
        r=await c.post('/api/auth/login',json={'password':'Dummy-test-passphrase-not-a-user-secret'})
        assert r.status_code==200,r.text
        header=r.headers['set-cookie'].lower();assert 'httponly' in header and 'secure' in header and 'samesite=lax' in header
        assert (await c.get('/api/state')).status_code==200
        assert (await c.get('/app')).status_code==200
        checks.append('correct password; HttpOnly Secure SameSite cookies; owner workspace allowed')
        token=c.cookies.get(auth.COOKIE);assert auth.valid_session(token)
        assert not auth.valid_session(token[:-1]+'x')
        assert not auth.valid_session('malformed')
        expired=auth.b64(json.dumps({'exp':int(time.time())-5,'v':__import__('hashlib').sha256(auth.PASSWORD_HASH.encode()).hexdigest()[:16]}).encode())
        sig=auth.b64(__import__('hmac').new(auth.SESSION_SECRET.encode(),expired.encode(),__import__('hashlib').sha256).digest())
        assert not auth.valid_session(expired+'.'+sig)
        checks.append('tampered/malformed/expired sessions rejected')
        assert (await c.post('/api/auth/logout',json={})).status_code==200
        assert (await c.get('/api/state')).status_code==401
        checks.append('logout clears owner access')
    # Local bridge token is useful only for narrow loopback desktop routes.
    local=httpx.ASGITransport(app=app,client=('127.0.0.1',23456))
    async with httpx.AsyncClient(transport=local,base_url='http://127.0.0.1:3000') as c:
        assert (await c.get('/api/desktop/meta')).status_code==401
        h={'X-Orbit-Desktop-Token':auth.DESKTOP_TOKEN}
        assert (await c.get('/api/desktop/meta',headers=h)).status_code==200
        assert (await c.get('/api/state',headers=h)).status_code==401
        assert (await c.get('/desktop-home',headers=h)).status_code==200
        checks.append('ephemeral narrow loopback bridge; no general API bypass')
    async with httpx.AsyncClient(transport=transport,base_url='https://owner.example') as c:
        assert (await c.get('/api/desktop/meta',headers={'X-Orbit-Desktop-Token':auth.DESKTOP_TOKEN})).status_code==401
        old=auth.PASSWORD_HASH;auth.PASSWORD_HASH=''
        assert (await c.post('/api/auth/login',json={'password':'anything'})).status_code==503
        assert (await c.get('/api/state')).status_code==401
        auth.PASSWORD_HASH=old
        checks.append('external bridge denied; missing credentials fail closed')
    # TestClient without lifespan context: no second local model process.
    client=TestClient(app,base_url='https://owner.example')
    try:
        with client.websocket_connect('/ws/desktop',headers={'Origin':'https://owner.example'}):
            raise AssertionError('Unauthenticated WebSocket was accepted')
    except WebSocketDisconnect as e:
        assert e.code==1008
    response=client.post('/api/auth/login',json={'password':'Dummy-test-passphrase-not-a-user-secret'})
    assert response.status_code==200
    with client.websocket_connect('wss://owner.example/ws/desktop',headers={'Origin':'https://owner.example'}) as ws:
        assert ws.receive_json()=={'starting':True}
    client.close()
    checks.append('WebSocket screen stream requires owner session')
    auth._attempts.clear()
    assert all(auth.login_allowed('rate-test') for _ in range(8))
    assert not auth.login_allowed('rate-test')
    checks.append('login attempt limiting')
    return {'passed':True,'checks':checks,'uses_dummy_credentials':True,'public_deployment_created':False}


if __name__=='__main__':
    result=asyncio.run(check())
    (ROOT/'verification/auth-v31.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))
