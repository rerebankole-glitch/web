"""Website + workbench Library/feedback UI, using an owned verifier."""
import asyncio
import json
import shutil
import sys
import uuid
from pathlib import Path
import requests
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
from app import store
BASE='http://127.0.0.1:3000'


def api(path,method='GET',**kwargs):
    r=requests.request(method,BASE+path,timeout=25,**kwargs);r.raise_for_status();return r.json()


async def run():
    before=api('/api/state');assert not before['runtime']['manual'] and not before['runtime']['active_task']
    original=before['selected'];aid=api('/api/agents','POST',json={'name':'Site UI '+uuid.uuid4().hex[:5],'role':'An owned website UI verifier.'})['id'];b=None
    try:
        async with async_playwright() as p:
            b=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
            page=await b.new_page(viewport={'width':1440,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
            await page.add_init_script('sessionStorage.setItem("orbit-agent",'+json.dumps(aid)+')')
            await page.goto(BASE,wait_until='networkidle');assert await page.title()=='Orbit — Your ideas, with room to work'
            await page.locator('.header-cta').click();await page.wait_for_url('**/app');await page.wait_for_function('typeof state!=="undefined" && state.runtime.engine_ready')
            await page.locator('[data-tab="knowledge"]').click()
            await page.locator('#knowledge-upload-input').set_input_files({'name':'studio-notes.md','mimeType':'text/markdown','buffer':b'The Juniper studio launch date is December 4, 2026.\nThe Juniper studio has four work tables.\n'})
            await page.wait_for_function('state.knowledge.documents===1',timeout=15000)
            await page.locator('#knowledge-question').fill('What is the Juniper studio launch date?')
            await page.locator('#knowledge-ask-button').click()
            await page.wait_for_function('state.messages.some(m=>m.role==="assistant" && m.content.includes("December 4, 2026"))',timeout=60000)
            message=page.locator('.message.assistant').last
            await message.locator('[data-score="-1"]').click()
            await page.locator('#feedback-correction').fill('Keep the launch date paired with its source.')
            await page.locator('#feedback-form button[type="submit"]').click()
            await page.wait_for_function('state.knowledge.needs_work===1')
            await page.locator('#knowledge-search').fill('Juniper launch')
            await page.locator('#knowledge-search-form button').click();await page.wait_for_selector('#knowledge-search-results article')
            await page.screenshot(path=str(ROOT/'verification/library-populated-v3.png'),full_page=True)
            await page.set_viewport_size({'width':390,'height':844})
            assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth')
            await page.screenshot(path=str(ROOT/'verification/library-mobile-v3.png'),full_page=True)
            await page.goto(BASE);await page.locator('#menu').click();assert await page.locator('#menu').get_attribute('aria-expanded')=='true'
            assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth')
            await page.goto(BASE+'/guide');assert await page.locator('#hardware').count()==1
            assert not errors,errors
            result={'passed':True,'errors':errors,'checks':['dedicated homepage to real workspace','Library upload/index UI','actual knowledge answer/citation in conversation','correction feedback UI','local search UI','responsive library/homepage','mobile menu','hardware improvement guide']}
            (ROOT/'verification/site-qa-v3.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
            await b.close();b=None
    finally:
        if b:
            try:await b.close()
            except Exception:pass
        with store.connect() as db:
            rows=db.execute('SELECT id FROM tasks WHERE agent=? AND state IN (?,?,?,?)',(aid,'queued','running','paused','waiting')).fetchall()
        for row in rows:
            try:api('/api/tasks/'+row['id']+'/stop','POST',json={})
            except Exception:pass
        await asyncio.sleep(.25)
        with store.connect() as db:
            db.execute('DELETE FROM knowledge_chunks WHERE agent=?',(aid,))
            for table in ['knowledge_documents','answer_feedback','messages','events','tasks']:db.execute(f'DELETE FROM {table} WHERE agent=?',(aid,))
            db.execute('DELETE FROM agents WHERE id=?',(aid,))
        shutil.rmtree(store.WORKSPACE/aid,ignore_errors=True)
        try:api('/api/desktop/launch','POST',json={'app':'browser','agent':original})
        except Exception:pass


if __name__=='__main__':asyncio.run(run())
