"""Real-inference regression test. Run only while the shared computer is idle.
Own temporary agent/data are removed in finally; user agents/files are untouched.
"""
import asyncio
import io
import json
import shutil
import sys
import time
import uuid
import zipfile
from pathlib import Path

import requests
import websockets
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from app import store, storage

BASE = 'http://127.0.0.1:3000'
http = requests.Session()
owned = ''
jobs = []
results = {}


def api(path, method='GET', **kwargs):
    r = http.request(method, BASE + path, timeout=45, **kwargs)
    r.raise_for_status()
    return r.json()


def task(prompt, approve=False, timeout=130):
    t = api('/api/tasks', 'POST', json={'agent': owned, 'prompt': prompt})
    jobs.append(t['id'])
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        s = api('/api/state', params={'agent': owned})
        row = next(x for x in s['tasks'] if x['id'] == t['id'])
        for approval in s['approvals']:
            if approval['task'] == t['id']:
                assert approve, 'Unexpected approval'
                # No terminal event may precede acceptance of this particular task.
                assert not any(e['kind'] == 'terminal' and e['task'] == t['id'] for e in s['events'])
                api('/api/approvals/' + approval['id'], 'POST', json={'approved': True})
        if row['state'] in {'done', 'error', 'stopped'}:
            assert row['state'] == 'done', row
            results[prompt] = {'state': row['state'], 'result': row['result']}
            print('PASS:', prompt, flush=True)
            return row['result'], s
        time.sleep(.65)
    raise TimeoutError(prompt)


async def stream_test():
    async with websockets.connect('ws://127.0.0.1:3000/ws/desktop', origin=BASE, max_size=2_000_000) as ws:
        image = await asyncio.wait_for(ws.recv(), timeout=12)
        assert isinstance(image, bytes) and image.startswith(b'\xff\xd8')
        return len(image)


def run():
    global owned
    before = api('/api/state')
    assert before['runtime']['engine_ready'] and before['runtime']['desktop_ready']
    assert not before['runtime']['manual'] and not before['runtime']['active_task'], 'Return control and let existing tasks finish before testing'
    original = before['selected']
    original_ids = {a['id'] for a in before['agents']}
    original_counts = {}
    with store.connect() as db:
        for aid in original_ids:
            original_counts[aid] = db.execute('SELECT COUNT(*) FROM messages WHERE agent=?', (aid,)).fetchone()[0]
    start = time.monotonic()
    results['passed'] = False
    owned = api('/api/agents', 'POST', json={'name': 'Verifier ' + uuid.uuid4().hex[:6], 'role': 'A careful concise verification assistant.', 'color': 'blue'})['id']
    (ROOT / '.cache').mkdir(exist_ok=True)
    (ROOT / '.cache/upgrade-test-owner.json').write_text(json.dumps({'agent': owned, 'original': original}))
    try:
        assert requests.get('http://127.0.0.1:8089/v1/models', timeout=5).status_code == 401
        assert before['runtime']['model_id'] == 'qwen35' and before['runtime']['vision']
        results['runtime'] = {k: before['runtime'][k] for k in ['model', 'vision', 'context', 'desktop_type', 'screen']}
        p = api('/api/agents/' + owned, 'PATCH', json={'memory': 'Use concise answers.'})
        assert p['memory'] == 'Use concise answers.'
        task('Remember that my favourite colour is green.')
        assert 'green' in next(a for a in api('/api/state', params={'agent': owned})['agents'] if a['id'] == owned)['memory']
        answer, _ = task('What is my favourite colour?')
        assert 'green' in answer.lower(), answer
        task('Create a practical 5-step morning checklist and save it to checkup.md')
        doc = api('/api/file', params={'agent': owned, 'path': 'checkup.md'})['content']
        assert len(doc) > 100 and '5.' in doc, doc
        assert not doc.strip().startswith('```')
        task('Create a small minimalist HTML website with the heading Hello Orbit, inline CSS, and one button. Save it to hello-orbit.html and show it on your desktop.')
        html = api('/api/file', params={'agent': owned, 'path': 'hello-orbit.html'})['content']
        assert '<' in html and 'Hello Orbit' in html, html
        rendered = http.get(BASE + '/preview/' + owned + '/hello-orbit.html', timeout=10)
        rendered.raise_for_status()
        assert "connect-src" not in rendered.headers['Content-Security-Policy'] or "'none'" in rendered.headers['Content-Security-Policy']
        assert "sandbox allow-scripts" in rendered.headers['Content-Security-Policy']
        assert '/preview/' in api('/api/health')['browser_url']
        task('Run the command "ls -la"', approve=True)
        task('Open my files')
        time.sleep(.8)
        png = http.get(BASE + '/api/screen', timeout=10)
        png.raise_for_status()
        (ROOT / 'verification/native-files-v2.jpg').write_bytes(png.content)
        description, _ = task('What is visible on your desktop right now?', timeout=150)
        assert len(description) > 20, description
        im = Image.new('RGB', (580, 280), '#eef2e6')
        draw = ImageDraw.Draw(im)
        font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 40)
        draw.text((50, 80), 'ORBIT  GREEN  GARDEN', font=font, fill='#27503a')
        buf = io.BytesIO(); im.save(buf, 'PNG')
        r = http.post(BASE + '/api/upload', data={'agent': owned}, files={'file': ('garden.png', buf.getvalue(), 'image/png')}, timeout=15)
        r.raise_for_status()
        description, _ = task('Describe the actual uploaded image garden.png and read its visible words.')
        assert 'green' in description.lower() or 'garden' in description.lower(), description
        answer, _ = task('Visit https://en.wikipedia.org/wiki/Windsor,_Ontario and save a short summary to windsor-check.md')
        assert 'https://en.wikipedia.org/wiki/Windsor,_Ontario' in answer
        text = api('/api/file', params={'agent': owned, 'path': 'windsor-check.md'})['content']
        assert len(text) > 100 and 'Source:' in text
        results['stream_frame_bytes'] = asyncio.run(stream_test())
        backup = http.get(BASE + '/api/agents/' + owned + '/export', timeout=45)
        backup.raise_for_status()
        with zipfile.ZipFile(io.BytesIO(backup.content)) as z:
            assert 'files/checkup.md' in z.namelist() and 'files/garden.png' in z.namelist()
            assert 'conversation.ndjson' in z.namelist()
            assert len(z.read('conversation.ndjson')) > 100
        assert http.get(BASE + '/api/file', params={'agent': owned, 'path': '../../README.md'}, timeout=10).status_code == 400
        assert http.post(BASE + '/api/browser/open', json={'url': 'http://127.0.0.1:8089'}, timeout=10).status_code == 400
        assert http.post(BASE + '/api/terminal', json={'agent': owned, 'command': 'ls; whoami'}, timeout=10).status_code == 400
        assert http.post(BASE + '/api/file', json={'agent': owned, 'path': 'bad.md', 'content': 'bad'}, headers={'Origin': 'https://unrelated.example'}, timeout=10).status_code == 403
        assert http.post(BASE + '/api/input', json={'kind': 'click', 'x': 20, 'y': 20}, timeout=10).status_code == 409
        u = api('/api/storage')
        assert u['used'] < u['limit'] and u['model_cache_persistent'] is False
        results['storage'] = u
        results['passed'] = True
        results['seconds'] = round(time.monotonic() - start, 2)
        print(json.dumps(results, indent=2), flush=True)
    finally:
        for tid in jobs:
            try: http.post(BASE + '/api/tasks/' + tid + '/stop', json={}, timeout=5)
            except requests.RequestException: pass
        time.sleep(.4)
        # Restore normal selected workspace before removing only our own verifier.
        try:
            api('/api/desktop/launch', 'POST', json={'app': 'browser', 'agent': original})
            api('/api/browser/home', 'POST', json={})
        except Exception: pass
        if owned and owned not in original_ids:
            with store.connect() as db:
                for table in ['messages', 'events', 'tasks']:
                    db.execute(f'DELETE FROM {table} WHERE agent=?', (owned,))
                db.execute('DELETE FROM agents WHERE id=?', (owned,))
            shutil.rmtree(store.WORKSPACE / owned, ignore_errors=True)
            storage.written()
        with store.connect() as db:
            for aid, count in original_counts.items():
                assert db.execute('SELECT COUNT(*) FROM messages WHERE agent=?', (aid,)).fetchone()[0] >= count, 'User conversation unexpectedly lost'
        (ROOT / 'verification/upgrade-test.json').write_text(json.dumps(results, indent=2))


if __name__ == '__main__':
    run()
