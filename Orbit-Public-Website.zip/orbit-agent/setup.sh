#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p logs
required=(chromium Xvfb fluxbox xdotool xterm xfwm4 xfce4-panel xfdesktop xfsettingsd thunar mousepad dbus-daemon tesseract wmctrl)
missing=0
for cmd in "${required[@]}"; do command -v "$cmd" >/dev/null || missing=1; done
if ((missing)); then
  if [[ $(id -u) == 0 ]]; then SUDO=(); else SUDO=(sudo); fi
  "${SUDO[@]}" apt-get update -qq
  "${SUDO[@]}" apt-get install -y --no-install-recommends chromium xvfb fluxbox xdotool xterm xfwm4 xfce4-panel xfdesktop4 xfce4-settings thunar mousepad dbus-x11 tesseract-ocr wmctrl hicolor-icon-theme adwaita-icon-theme fonts-dejavu-core fonts-liberation x11-utils x11-xserver-utils python3-venv python3-pip
fi
if ! python3 -m venv .venv; then
  if [[ $(id -u) == 0 ]]; then SUDO=(); else SUDO=(sudo); fi
  "${SUDO[@]}" apt-get update -qq
  "${SUDO[@]}" apt-get install -y python3-venv python3-pip
  python3 -m venv .venv
fi
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python download_runtime.py
printf '\nReady. Start with: bash start.sh\n'
