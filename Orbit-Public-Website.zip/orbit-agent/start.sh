#!/usr/bin/env bash
# Durable entrypoint: restores disposable OS/Python dependencies when needed.
# The web server itself verifies/restores the selected model cache in the background.
set -euo pipefail
cd "$(dirname "$0")"
PY=python3
if [[ -x .venv/bin/python ]]; then PY=.venv/bin/python; fi
missing=0
for cmd in chromium Xvfb xdotool xterm xfwm4 xfce4-panel xfdesktop xfsettingsd thunar mousepad dbus-daemon tesseract wmctrl; do
  command -v "$cmd" >/dev/null || missing=1
done
if ! "$PY" -c 'import fastapi,uvicorn,httpx,playwright,mss,PIL,multipart,websockets,requests' >/dev/null 2>&1; then missing=1; fi
if ((missing)); then
  echo 'Restoring Orbit dependencies (sudo may be needed on your own computer)…'
  bash setup.sh
  PY=.venv/bin/python
fi
exec "$PY" run.py
