# Orbit 3.1 — your ideas, with room to work

A local-first AI workbench with **a real Linux desktop**, not a chat mockup. Independent of Grok Bot, xAI, and Cursor.

Orbit's custom controller, website, file tools, memory, and approval gates are ours. The brain uses **existing open-weight Qwen models**, not a foundation model trained from scratch. **No external AI inference API, subscription, or user-supplied API key.** Internal frontend/backend/local-inference HTTP endpoints are used.

## What's upgraded

- **Qwen3.5 0.8B Q5_K_M** replaces Qwen2.5 0.5B Q4 as the default; optional F16 vision projector is enabled by default. Small, newer, and genuinely image-capable.
- **4,096-token context**, non-thinking mode, CPU inference, and bounded structured task planning. Conservative settings for the available **2 GB RAM / 2 cores**, with runtime prompt RAM caching/checkpoints disabled to prevent repeated-task memory thrashing.
- **Actual screenshot inspection** with local vision + OCR, and descriptions of uploaded PNG/JPEG/WebP images.
- **Real XFCE desktop** at 1024 × 640: Chromium, Thunar files, Mousepad notes, and Xterm. Bigger native fonts, custom wallpaper, native launchers, show-desktop control.
- Redesigned responsive workbench and desktop-home website, light/dark web theme, live desktop WebSocket streaming with HTTP fallback, mouse dragging/scrolling/keyboard takeover.
- Real HTML/SVG/image previews; generated websites can open on the desktop. Artifact previews are sandboxed and external networking is blocked.
- Editable per-agent role and **pinned memory**. Saying `Remember that…` saves an explicit preference. This is prompt context—not retraining or perfect unlimited memory.
- **Saved-project storage meter**, budget-checked app writes/uploads, file deletion with confirmation, streaming agent backups, and source export.
- **Automatic model-cache restoration at boot**; startup scripts restore missing OS/Python dependencies when installation privileges are available.

This is the stronger, practical configuration tested here—not a claim to be the world's best AI. Larger models require more RAM, not just a bigger saved-project quota.


## New: deployment login and public hosting package

The normal Arena development preview remains separate from public deployment. For your own HTTPS host, run `create_auth.py` interactively to choose an owner passphrase, then `bash public_start.sh`. Private HTTP endpoints and WebSocket desktop streaming require owner login; the homepage/guide remain public. Eight-hour signed sessions use HttpOnly secure cookies. Incorrect logins are rate-limited. Native launchers use a separate ephemeral loopback token. This is single-owner access control—not isolated multi-user computers or a production security guarantee.

**Read `HOSTING.md` for the free, usage-limited Codespaces path.** `.devcontainer/` prepares the full Linux app; you must create it in your own account and copy its actual forwarded port URL. The assistant has not created an external account, repository, Codespace, server, domain, or public link. Optional Docker/Compose/Caddy configuration is included for your own host; Docker/ARM builds have not been executed here.

Never commit `.orbit-owner.env`. It contains a salted password hash and signing secret, not a plaintext password. No real owner password is generated or supplied by the builder. The source package excludes credentials and user data.

## New: your own AI website and useful local knowledge

- `/` is the dedicated Orbit homepage, with real workspace links, feature explanations, boundaries, and a practical improvement guide.
- `/app` retains the actual chat/desktop/file workbench. `/app#knowledge` opens **Library**.
- Add TXT, Markdown, CSV, JSON, or HTML reference material in Library (2 MB each). Sources are stored in that agent's workspace and indexed with **local SQLite FTS5**—no hosted embedding API.
- Ask in Library, or ask a matching factual question in chat. Orbit retrieves relevant chunks, uses the actual local model to select source sentences, preserves their wording, and links to the source document. It declines unsupported library answers.
- Source contents are untrusted data, not instructions. The knowledge answer flow cannot execute embedded commands. Integrity checks prevent a manually modified/deleted source copy from being cited as current; re-upload revisions to rebuild the index.
- Assistant answers now have **Helpful / Needs work** feedback. Corrections are saved locally and exported as NDJSON. These are review/evaluation records, **not automatic model training**.
- Agent backups now include knowledge-source metadata, source files, and feedback. Existing conversations/files are preserved.

### What actually makes the AI better?

1. Trustworthy documents + source-based retrieval improve factual context without changing weights.
2. Focused roles/pinned preferences help follow your workflow.
3. Corrections + a consistent test set let you measure and improve reliability.
4. More RAM/compatible GPU on your own host allows larger models. Current weights are still Qwen3.5 0.8B Q5 + vision; this sandbox remains approximately 2 GB RAM / 2 CPUs.
5. Fine-tuning is a separate, compute-intensive process requiring clean permissioned examples and evaluation. No competitive foundation model can be trained from scratch within this project's resources.

Use saved storage for sources, indexes, code, conversations, and feedback—not filler. Budget checks reserve room for index/WAL growth and bookkeeping. The actual platform snapshot limit remains authoritative. Knowledge queries use lexical retrieval, so precise keywords and clean factual sentences help. Other formats must be exported as text first.

A GPU upgrade also needs a **GPU-enabled llama.cpp build and configuration**. The bundled runtime is CPU-oriented; simply owning a GPU does not automatically enable offloading. Review model/runtime requirements before buying hardware or switching models.

Verification:

```bash
python tests/knowledge_test.py  # actual source-based inference, feedback, ownership, integrity, backups
python tests/control_test.py    # actual desktop click/type/drag
```

## Open the live app

Use **Orbit AI website** in Arena's **Live preview** panel. The dedicated homepage is at `/`; choose **Open workspace** to enter `/app`. The improvement guide is at `/guide`. A bare public sandbox URL can be blocked by Arena's traffic protection; use the authenticated panel. This is a development session, not permanent hosting.

Try:

```text
Create a practical 5-step morning checklist and save it to morning-plan.md

Create a simple stylish website about a little garden with inline CSS and save it to garden.html. Show the website on the desktop.

What is visible on your desktop right now?

Open my files

Remember that I prefer concise answers and Canadian spelling.

Visit https://en.wikipedia.org/wiki/Windsor,_Ontario and save a short summary to windsor.md

Run the command "ls -la"
```

**Files**: attach/upload text, code, HTML, SVG, or images (2 MB per file); edit text; preview; download; delete explicitly. Large text previews are read-only excerpts. Images can be described by the AI.

**Take control**: click, drag, scroll, type, use shortcuts, or paste text through the Type field. The AI waits before its next action; an in-progress inference may finish. **Return to agent** resumes it. Expand the computer for readable native text.

**App dock**: launches actual native applications. Opening an app while the AI is working pauses it for takeover. The native shell has the broad access of a real user; AI-issued terminal tools remain allowlisted and approval-gated.

**Agent details**: edit name, role, and up to 2,000 characters of pinned notes. Multiple agents have separate conversations/files but **share one model, browser, and computer**. Tasks are serialized—not isolated VMs.

## The 128 MB saved-project budget

Models are not squeezed into 128 MB. **Saved code, website, SQLite conversations, user files, logs, and source ZIP count; rebuildable caches do not.** The selected Qwen3.5 weights are about **590 MB**, plus a **205 MB** vision projector; they live in `~/.cache/orbit` and are not included in source archives or Arena saved snapshots.

The default app limit is **128,000,000 bytes**, with a 3 MB reserve for bookkeeping. Writes and uploads are checked; a meter accounts for snapshot-relevant files. Native/manual filesystem operations are not subject to a hard OS quota, and Arena's actual snapshot rules remain authoritative. No user files are automatically deleted. File-count guardrails also apply.

**How to get more durable storage:**

1. This app cannot change Arena's quota. No Arena storage-upgrade control has been verified; consult [Arena Help](https://help.arena.ai/) for account/quota options.
2. For a complete migration, use **Arena Workspace → Download**. Keep the project **including `workspace/` and `.orbit.sqlite`**, then run it on your own Linux computer or a larger server. Official instructions: [How to use Agent Mode](https://help.arena.ai/articles/5432423882-how-to-use-agent-mode).
3. On your own host, increase the app's guard, for example `ORBIT_PROJECT_LIMIT_MB=1024 bash start.sh`. **This does not increase Arena's platform quota.** Put model cache on a large disk with `ORBIT_CACHE=/your/large/disk/orbit-cache`.

The provided **source ZIP excludes all user data and model weights**. In-app **Agent backup** exports that agent's files, profile, complete conversation, tasks, and activity as ZIP/NDJSON. It is a portable backup, not a one-click restore feature. Arena's full-workspace export is the easiest way to preserve the live SQLite database for migration.

## Run your own copy

**x86-64 Debian/Ubuntu Linux**, Python 3.11+, AVX2-capable CPU. 2 GB was tested with the small model; **4 GB+ recommended** for comfortable browsing. More RAM lets you run larger model profiles. Initial model/runtime/package downloads require internet; inference afterward is local.

```bash
cd orbit-agent
bash start.sh
```

First launch may invoke `setup.sh` and require `sudo`. Visit `http://localhost:3000` **on that computer**. The app binds `0.0.0.0`, accepts the preview host, and uses relative browser-facing URLs. On a remote server, use authenticated private access; do not expose this development app publicly.

Configuration:

| Variable | Default / meaning |
|---|---|
| `PORT` | `3000`, web workbench |
| `ORBIT_CACHE` | `~/.cache/orbit`, disposable models/runtime/browser/desktop configuration |
| `ORBIT_MODEL` | `qwen35`; `qwen25` is the old low-memory text-only fallback |
| `ORBIT_VISION` | `1`; use `0` to reduce memory usage |
| `ORBIT_PROJECT_LIMIT_MB` | `128`; increase only on your own larger host |
| `ORBIT_STORAGE_ROOT` | Arena home in an Arena sandbox; project folder on other hosts |

Example low-memory fallback:

```bash
ORBIT_VISION=0 bash start.sh
# or
ORBIT_MODEL=qwen25 bash start.sh
```

`models.json` contains download filenames, exact sizes, and SHA-256 hashes. `download_runtime.py` verifies model/projector hashes and restores missing files. llama.cpp is pinned to **b11541**, tested with the default model. The local model endpoint is on loopback `8089` with an automatically generated internal authentication key—not an external provider key. Desktop X display is `:97`.

## Architecture

```text
Your browser → FastAPI workbench
  ├─ SQLite: agents, preferences, messages, tasks, activity
  ├─ bounded task controller + approvals
  │   └─ llama.cpp → local Qwen3.5 language/vision model
  ├─ Playwright → real Chromium on Xvfb + XFCE
  ├─ Thunar / Mousepad / Xterm / native launchers
  ├─ workspace-confined file tools, uploads, previews, exports
  └─ actual screen streaming + xdotool input
```

- `app/agent.py`: intents and verified tool recipes.
- `app/runtime.py`: local model/computer lifecycle and real tools.
- `app/desktop.py`: regenerated native XFCE environment.
- `app/storage.py`: saved-file accounting and app write guards.
- `app/server.py`: dashboard, screen, file, memory, and export routes.
- `workspace/.orbit.sqlite`: durable user database; `workspace/<agent-id>/`: durable files. **Preserve these.**

Research remains **extractive and source-grounded**: the model selects sentence IDs and the controller quotes actual source wording and URL. This reduces invented summary claims, but source quality and selection still need review.

## Safety and limits

- Small local models can misclassify requests, hallucinate, and generate imperfect code. Verify important answers and artifacts.
- Vision describes screenshots/images; it is **not unrestricted autonomous clicking in arbitrary GUI apps**. Browser/command/file actions use bounded workflows.
- AI terminal allowlist: `pwd ls date uname whoami cat head wc du df echo`. No arbitrary scripts, pipes, redirects, or shell operators. Approval comes before execution and before agent file replacement.
- File tools reject absolute paths, traversal, hidden files, and escapes through symlinks.
- No login/CAPTCHA bypass, automatic external messages/payments/account mutation, or inherited Arena connector credentials.
- Prompts/screenshots stay on the local model. Public browsing sends normal internet requests. Weights/packages are downloaded initially.
- Single-user development server; same-origin write checks and a private authenticated model endpoint are defense in depth, **not production authentication or hardened VM isolation**. Chromium runs with `--no-sandbox` inside the existing development computer. Avoid sensitive accounts.
- Processes, installed packages, and excluded caches may disappear between development sessions. Source and workspace data are durable subject to Arena's snapshot limits. `start.sh` restores dependencies when possible; `runtime.boot()` restores model cache automatically.

## Verification

With the service idle and not in manual takeover:

```bash
python tests/upgrade_test.py
```

The upgrade test uses real local inference and actual tools; creates only its own temporary verifier agent; checks files/HTML rendering, source-grounded research, image and screen reading, pinned memory, native app launch, streaming, approvals, exports, and safety checks; and cleans only its own test records in `finally`. Frontend screenshots and verification JSON are in `verification/`. Test scripts are not a guarantee of production security or general model accuracy.

Bundled DM Sans / DM Mono fonts are under their SIL Open Font Licenses in `licenses/`. Model/runtime software retains its own upstream licenses.
