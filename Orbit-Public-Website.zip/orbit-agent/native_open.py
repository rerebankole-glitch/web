#!/usr/bin/env python3
"""Trusted local desktop launchers; not an external API or a shell tool."""
import os
import sys
import requests

if __name__ == '__main__':
    app = sys.argv[1] if len(sys.argv) > 1 else 'browser'
    try:
        r = requests.post('http://127.0.0.1:' + os.environ.get('PORT', '3000') + '/api/desktop/launch', json={'app': app}, headers={'X-Orbit-Desktop-Token': os.environ.get('ORBIT_DESKTOP_TOKEN', '')}, timeout=30)
        r.raise_for_status()
    except Exception as exc:
        print('Could not open the desktop app:', exc)
