'use strict';
const $ = id => document.getElementById(id);
const icon = name => `<svg class="icon" aria-hidden="true"><use href="#${name}"/></svg>`;
const escapeHTML = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let state = null, selectedAgent = sessionStorage.getItem('orbit-agent') || '', currentTab = 'desktop';
let messageSignature = '', navSignature = '', fileSignature = '', activitySignature = '', terminalSignature = '';
let sending = false, screenBusy = false, screenInterval = 1100, lastFrame = 0, toastTimer, loadSequence = 0, inputQueue = Promise.resolve();
let newAgentColor = 'sage', editingFile = '';

async function api(path, method = 'GET', body) {
  const opts = {method, headers: {'Content-Type':'application/json'}};
  if (body !== undefined) opts.body = JSON.stringify(body);
  const res = await fetch(path, opts);
  let data;
  try { data = await res.json(); } catch { throw new Error('The server returned an unexpected response.'); }
  if (!res.ok) throw new Error(typeof data.detail === 'string' ? data.detail : `Request failed (${res.status}).`);
  return data;
}
function toast(text, error = false) {
  clearTimeout(toastTimer); $('toast').textContent = text; $('toast').classList.toggle('error',error); $('toast').hidden = false;
  toastTimer = setTimeout(() => $('toast').hidden = true, 4500);
}
function timeLabel(ts) {return new Date(ts * 1000).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});}
function shortAge(ts) {const n = Math.max(0, Math.floor(Date.now()/1000-ts)); return n<60 ? 'now' : n<3600 ? `${Math.floor(n/60)}m` : `${Math.floor(n/3600)}h`;}
function agent() {return state?.agents.find(a => a.id === selectedAgent) || state?.agents[0];}
function markdown(s) {
  const blocks = String(s).split(/(```[\s\S]*?```)/g);
  return blocks.map(b => {
    if (b.startsWith('```')) return `<pre><code>${escapeHTML(b.replace(/^```[^\n]*\n?/, '').replace(/\n?```$/, ''))}</code></pre>`;
    let t = escapeHTML(b).replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>').replace(/`([^`\n]+)`/g,'<code>$1</code>');
    t = t.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+|\/api\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
    t = t.replace(/^#{1,3}\s+(.+)$/gm,'<strong>$1</strong>');
    t = t.split('\n').map(line => /^\s*[-*]\s+/.test(line) ? `<div class="md-bullet"><span>${line.replace(/^\s*[-*]\s+/,'')}</span></div>` : line).join('\n');
    return `<p>${t.replace(/\n\n/g,'</p><p>').replace(/\n/g,'<br>')}</p>`;
  }).join('');
}
function iconFor(kind) {return {brain:'brain',browser:'globe',read:'file',file:'file',terminal:'terminal',approval:'shield',complete:'check',stop:'stop',error:'activity'}[kind] || 'activity';}
function invalidate() {messageSignature=navSignature=fileSignature=activitySignature=terminalSignature='';}
async function loadState() {
  const seq = ++loadSequence, expected = selectedAgent;
  try {
    const data = await api('/api/state' + (selectedAgent ? `?agent=${encodeURIComponent(selectedAgent)}` : ''));
    if (seq !== loadSequence || expected !== selectedAgent) return;
    state = data; selectedAgent = data.selected; sessionStorage.setItem('orbit-agent', selectedAgent); render();
  } catch (e) {
    if (/Agent not found/.test(e.message) && selectedAgent) {selectedAgent='';loadState();return;}
    $('engine-label').textContent = 'Connection interrupted'; $('engine-dot').className = 'status-dot error';
    $('desktop-label').textContent = 'Reconnecting'; $('send').disabled = true;
  }
}
function render() {
  const a = agent(), rt = state.runtime;
  document.title = `Orbit · ${a.name}`;
  $('crumb-agent').textContent = a.name; $('active-name').textContent = a.name;
  $('active-description').textContent = a.role;
  $('active-avatar').className = `agent-avatar ${a.color}`;
  $('prompt').placeholder = `What should ${a.name} work on?`;
  $('agent-count').textContent = state.agents.length;
  $('engine-label').textContent = rt.engine_ready ? 'Qwen · running locally' : rt.error ? 'Runtime needs attention' : rt.phase;
  $('engine-dot').className = 'status-dot' + (rt.engine_ready ? ' online' : rt.error ? ' error' : '');
  $('desktop-label').textContent = rt.desktop_ready ? 'Sandbox online' : 'Computer starting';
  $('desktop-dot').className = 'status-dot' + (rt.desktop_ready ? ' online' : '');
  $('take-control').classList.toggle('controlling', rt.manual);
  $('take-control').querySelector('span').textContent = rt.manual ? 'Return to agent' : 'Take control';
  $('control-input').hidden = !rt.manual; $('control-tag').hidden = !rt.manual;
  $('screen-viewport').classList.toggle('controlling',rt.manual);
  $('files-count').textContent = state.files.length;
  $('token-stat').textContent = rt.tokens ? `${rt.tokens.toLocaleString()} tokens · ${rt.tokens_per_second} t/s` : 'Local inference';
  if (rt.browser_url) {
    try {const u=new URL(rt.browser_url);$('screen-location').textContent=u.hostname==='127.0.0.1' ? 'orbit / sandbox' : u.hostname+u.pathname;} catch {}
  }
  if (rt.error) { $('screen-loading').querySelector('strong').textContent='The computer needs attention';$('screen-loading').querySelector('span').textContent=rt.error; }
  const ns = JSON.stringify(state.agents);
  if (ns !== navSignature) {
    navSignature = ns;
    $('agent-list').innerHTML = state.agents.map(x => `<button class="agent-item ${x.id===selectedAgent?'active':''}" data-agent="${x.id}" title="${escapeHTML(x.role)}"><div class="agent-avatar ${x.color}"><svg><use href="#orbit"/></svg></div><span><strong>${escapeHTML(x.name)}</strong><small>${x.status==='idle'?'Ready to help':{waiting:'Needs approval',running:'Working',queued:'Queued',paused:'You’re in control'}[x.status]||x.status}</small></span><i class="agent-indicator ${x.status!=='idle'?'busy':''}"></i></button>`).join('');
  }
  const active = state.tasks.find(t => ['running','waiting','paused','queued'].includes(t.state));
  $('task-banner').hidden = !active; $('working-indicator').hidden = !active;
  if (active) {
    const label = {running:'Working on your task',waiting:'Waiting for your approval',paused:'Paused while you have control',queued:'Task queued'}[active.state];
    $('task-banner').innerHTML = `<span>${icon(active.state==='waiting'?'shield':'activity')}${label}</span><button data-stop-task="${active.id}">${icon('stop')}Stop</button>`;
    $('working-indicator').querySelector('span:last-child').textContent = label;
  }
  const ms = JSON.stringify(state.messages);
  if (ms !== messageSignature) {
    const feed = $('conversation-scroll'), nearBottom = feed.scrollHeight - feed.scrollTop - feed.clientHeight < 130;
    const first = !messageSignature; messageSignature = ms;
    const started = state.messages.some(m=>m.role==='user');
    $('welcome').hidden = started; $('messages').hidden = !started;
    $('messages').innerHTML = started ? state.messages.map(m => `<article class="message ${m.role}">${m.role==='assistant'?`<div class="message-header">${icon('orbit')}<span>${escapeHTML(a.name)}</span><time>${timeLabel(m.created)}</time></div>`:''}<div class="message-body">${markdown(m.content)}</div>${m.role==='assistant'?`<div class="message-feedback"><button data-feedback="${m.id}" data-score="1" title="This answer was helpful">${icon('like')}Helpful</button><button data-feedback="${m.id}" data-score="-1" title="Save a correction">Needs work</button></div>`:''}</article>`).join('') : '';
    if (started && (nearBottom || first)) requestAnimationFrame(()=>feed.scrollTop=feed.scrollHeight);
  }
  $('approvals').innerHTML = state.approvals.map(x => `<div class="approval-card"><strong>${icon('shield')}${escapeHTML(x.title)}</strong><pre>${escapeHTML(x.detail)}</pre><div class="approval-actions"><button data-approval="${x.id}" data-approved="false">Decline</button><button class="approve" data-approval="${x.id}" data-approved="true">Approve & continue</button></div></div>`).join('');
  const fs = JSON.stringify(state.files);
  if (fs !== fileSignature) {
    fileSignature = fs;
    $('file-list').innerHTML = state.files.length ? state.files.map(f=>`<div class="file-row">${icon('file')}<button class="file-row-main" data-file="${escapeHTML(f.name)}"><strong>${escapeHTML(f.name)}</strong><small>${bytes(f.size)} <b>·</b> ${new Date(f.modified*1000).toLocaleDateString([], {month:'short',day:'numeric'})}</small></button><a href="${downloadUrl(f.name)}" download title="Download ${escapeHTML(f.name)}">${icon('download')}</a></div>`).join('') : `<div class="empty-files">${icon('file')}Your workspace is ready.<br>Create a file or ask your agent to write one.</div>`;
  }
  const events = state.events.slice(0,4);
  const es = JSON.stringify(events);
  if (es !== activitySignature) {
    activitySignature=es;
    $('activity-preview').innerHTML = events.length ? events.slice().reverse().map(e=>`<div class="activity-item"><span class="activity-symbol ${e.state}">${icon(iconFor(e.kind))}</span><div class="activity-text"><strong>${escapeHTML(e.label)}</strong><p>${escapeHTML(e.detail.split('\n')[0])}</p></div><time>${shortAge(e.created)}</time></div>`).join('') : `<div class="empty-activity">${icon('activity')}<p>Nothing hidden. Every action<br>will leave a trail here.</p></div>`;
  }
  const ts=JSON.stringify(state.terminal);
  if(ts!==terminalSignature){
    terminalSignature=ts;
    $('terminal-output').innerHTML=state.terminal.length ? state.terminal.map(r=>`<div class="terminal-record"><div class="command">$ ${escapeHTML(r.command)}</div><div>${escapeHTML(r.output)}</div><div class="exit">exit ${r.code} · ${timeLabel(r.time)}</div></div>`).join('') : `<div class="terminal-empty">ORBIT / SHELL<br><br>No commands run yet.<br>Your real command output will appear here.</div>`;
    $('terminal-output').scrollTop=$('terminal-output').scrollHeight;
  }
  renderUpgrade(); updateSend(); refreshScreen();
}
function updateSend() { $('send').disabled = sending || !state?.runtime.engine_ready || !$('prompt').value.trim(); }
async function sendTask(e) {
  e?.preventDefault();const prompt=$('prompt').value.trim(); if(!prompt||sending||!state?.runtime.engine_ready)return;
  sending=true;updateSend();
  try{await api('/api/tasks','POST',{agent:selectedAgent,prompt});$('prompt').value='';await loadState();const f=$('conversation-scroll');f.scrollTop=f.scrollHeight;}
  catch(e){toast(e.message,true);}finally{sending=false;updateSend();$('prompt').focus();}
}
async function selectAgent(id){selectedAgent=id;sessionStorage.setItem('orbit-agent',id);invalidate();await loadState();}
function switchTab(tab){
  currentTab=tab;['desktop','files','terminal','knowledge'].forEach(t=>{$(t+'-tab').hidden=t!==tab;document.querySelector(`[data-tab="${t}"]`).classList.toggle('active',t===tab);});
  document.querySelectorAll('[data-nav]').forEach(n=>n.classList.toggle('selected',n.dataset.nav===(tab==='files'?'files':tab==='knowledge'?'knowledge':'agents')));
  if(tab==='desktop')refreshScreen(true);else closeStream();
  if(window.innerWidth<711)$('computer-panel').scrollIntoView({behavior:'smooth'});
}
function downloadUrl(path){return `/api/file/download?agent=${encodeURIComponent(selectedAgent)}&path=${encodeURIComponent(path)}`;}
function modal(title,body,wide=false){$('modal-content').className='modal'+(wide?' wide':'');$('modal-content').innerHTML=`<div class="modal-header"><h2 id="modal-title">${title}</h2><button class="icon-button" data-close aria-label="Close dialog">${icon('close')}</button></div>${body}`;$('modal').hidden=false;setTimeout(()=>$('modal-content').querySelector('input,textarea,button')?.focus(),30);}
function closeModal(){$('modal').hidden=true;$('prompt').focus();}
function showNewAgent(){
  newAgentColor='sage';
  modal('A new teammate.',`<p class="subhead">Give it a name and a job. Each agent keeps its own conversation and workspace, and shares the sandbox desktop.</p><form id="new-agent-form"><label for="agent-name-input">Name</label><input id="agent-name-input" maxlength="32" placeholder="e.g. Scout" required><label for="agent-role-input">What is its job?</label><textarea id="agent-role-input" rows="3" maxlength="500" placeholder="Research topics, check sources, and save clear notes." required></textarea><label>Pick a color</label><div class="color-options">${['sage','clay','blue','lilac'].map(c=>`<button type="button" class="color-choice ${c} ${c==='sage'?'active':''}" data-color="${c}" aria-label="${c}"></button>`).join('')}</div><div class="modal-footer"><button type="button" class="secondary-button" data-close>Cancel</button><button class="primary-button" type="submit">${icon('plus')}Create agent</button></div></form>`);
  $('new-agent-form').addEventListener('submit',async e=>{e.preventDefault();try{const a=await api('/api/agents','POST',{name:$('agent-name-input').value,role:$('agent-role-input').value,color:newAgentColor});closeModal();await selectAgent(a.id);toast(`${a.name} is ready.`);}catch(e){toast(e.message,true);}});
}
function showNewFile(){modal('Make a little room for an idea.',`<p class="subhead">Create a real text file in this agent’s workspace.</p><form id="new-file-form"><label for="file-name">File name</label><input id="file-name" placeholder="notes.md" required><label for="file-content">Contents</label><textarea id="file-content" rows="9" placeholder="Start writing…"></textarea><div class="modal-footer"><button type="button" class="secondary-button" data-close>Cancel</button><button type="submit" class="primary-button">Create file</button></div></form>`);$('new-file-form').onsubmit=async e=>{e.preventDefault();try{const path=$('file-name').value.trim();if(state.files.some(f=>f.name===path))throw new Error('That file already exists. Open it to edit instead.');await api('/api/file','POST',{agent:selectedAgent,path,content:$('file-content').value});closeModal();toast('File created.');await loadState();}catch(e){toast(e.message,true);}};}
async function showActivity(){
  try{const data=await api('/api/activity');modal('Nothing behind the curtain.',`<p class="subhead">The actual action log across your agents. Expand an entry to see the tool result. These are actions—not private model reasoning.</p>${data.events.length?data.events.map(e=>`<details><summary>${icon(iconFor(e.kind))}<span>${escapeHTML(e.label)}</span><small>${escapeHTML(e.state)} · ${timeLabel(e.created)}</small></summary><pre>${escapeHTML(e.detail)}</pre></details>`).join(''):'<p class="settings-note">No actions yet. Give your agent its first task.</p>'}`,true);}catch(e){toast(e.message,true);}
}
function showOpenURL(){modal('Where shall we go?',`<p class="subhead">Open a public website on the agent’s Chromium browser. The agent’s computer is separate from your device.</p><form id="url-form"><label for="website-url">Website URL</label><input type="url" id="website-url" placeholder="https://en.wikipedia.org" required><div class="modal-footer"><button type="button" class="secondary-button" data-close>Cancel</button><button type="submit" class="primary-button">${icon('globe')}Open website</button></div></form>`);$('url-form').onsubmit=async e=>{e.preventDefault();try{toast('Opening the website…');await api('/api/browser/open','POST',{url:$('website-url').value});closeModal();switchTab('desktop');refreshScreen(true);}catch(e){toast(e.message,true);}};}
async function toggleControl(){try{const active=!state.runtime.manual;await api('/api/control','POST',{active});await loadState();toast(active?'You have control. Click the screen and type. The agent pauses before its next action.':'Control returned to the agent.');if(active){switchTab('desktop');$('screen-viewport').focus();}}catch(e){toast(e.message,true);}}
function sendInput(data){inputQueue=inputQueue.then(()=>api('/api/input','POST',data)).then(()=>{setTimeout(()=>refreshScreen(true),100);}).catch(e=>toast(e.message,true));return inputQueue;}

$('composer').addEventListener('submit',sendTask);
$('prompt').addEventListener('input',updateSend);
$('prompt').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendTask();}});
$('new-agent').onclick=$('add-agent-small').onclick=showNewAgent;
$('settings').onclick=$('agent-details').onclick=$('about-link').onclick=showSettings;
$('view-activity').onclick=showActivity;
$('new-file').onclick=showNewFile;
$('composer-files').onclick=()=>switchTab('files');
$('take-control').onclick=toggleControl;
$('open-url').onclick=showOpenURL;
$('computer-home').onclick=async()=>{try{await api('/api/browser/home','POST',{});refreshScreen(true);}catch(e){toast(e.message,true);}};
$('expand-computer').onclick=()=>{$('computer-panel').classList.toggle('expanded');};
$('type-remote').onclick=()=>{const text=$('remote-text').value;if(text){sendInput({kind:'text',text});$('remote-text').value='';}};
$('enter-remote').onclick=()=>sendInput({kind:'key',key:'Enter'});
$('remote-text').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();$('type-remote').click();}});
$('terminal-form').onsubmit=async e=>{e.preventDefault();const command=$('terminal-command').value.trim();if(!command)return;const btn=e.target.querySelector('button');btn.disabled=true;try{await api('/api/terminal','POST',{agent:selectedAgent,command});$('terminal-command').value='';await loadState();}catch(e){toast(e.message,true);}finally{btn.disabled=false;}};
$('modal').addEventListener('click',e=>{if(e.target===$('modal'))closeModal();});
document.addEventListener('keydown',e=>{if(e.key==='Escape'){if(!$('modal').hidden)closeModal();else $('computer-panel').classList.remove('expanded');}});
document.addEventListener('click',async e=>{
  const closest=s=>e.target.closest(s);
  if(closest('[data-close]'))closeModal();
  const ab=closest('[data-agent]');if(ab)await selectAgent(ab.dataset.agent);
  const tab=closest('[data-tab]');if(tab)switchTab(tab.dataset.tab);
  const nav=closest('[data-nav]');if(nav){if(nav.dataset.nav==='activity')showActivity();else if(nav.dataset.nav==='files')switchTab('files');else if(nav.dataset.nav==='knowledge')switchTab('knowledge');else {switchTab('desktop');$('prompt').focus();if(innerWidth<711)$('conversation-scroll').scrollIntoView({behavior:'smooth'});}}
  const starter=closest('[data-starter]');if(starter){const examples={website:'Create a simple stylish website about a little garden with inline CSS and save it to garden.html. Show the website on the desktop.',vision:'What is visible on your desktop right now?',research:'Visit https://en.wikipedia.org/wiki/Windsor,_Ontario and save a short summary to windsor.md',file:'Create a practical 5-step morning checklist and save it to morning-plan.md',terminal:'Run the command "ls -la"'};$('prompt').value=examples[starter.dataset.starter];updateSend();$('prompt').focus();}
  const file=closest('[data-file]');if(file)showFile(file.dataset.file);
  const color=closest('[data-color]');if(color){newAgentColor=color.dataset.color;document.querySelectorAll('[data-color]').forEach(b=>b.classList.toggle('active',b===color));}
  const stop=closest('[data-stop-task]');if(stop){try{await api(`/api/tasks/${stop.dataset.stopTask}/stop`,'POST',{});await loadState();toast('Task stopped.');}catch(e){toast(e.message,true);}}
  const approve=closest('[data-approval]');if(approve){approve.disabled=true;try{await api(`/api/approvals/${approve.dataset.approval}`,'POST',{approved:approve.dataset.approved==='true'});await loadState();}catch(e){toast(e.message,true);}}
});
loadState();setInterval(loadState,1400);setInterval(()=>refreshScreen(),350);

// V2: real multimodal runtime, native apps, streaming, pinned memory, and storage.
let desktopSocket=null, streamActive=false, frameURL='', streamReconnect=null, dragging=false, lastMove=0;
let desktopPaused=false,nextStreamTry=0;
const savedTheme=localStorage.getItem('orbit-theme')||'light';
document.documentElement.dataset.theme=savedTheme;

function bytes(n){return n>=1e6?`${(n/1e6).toFixed(2)} MB`:n>=1000?`${(n/1000).toFixed(1)} KB`:`${n} B`;}
function renderUpgrade(){
 renderLibraryStats();
 const r=state.runtime,u=state.storage;
 $('owner-logout').hidden=!state.auth_required;
 $('model-short').textContent=r.model.split(' · ')[0];
 $('engine-label').textContent=r.engine_ready?r.model.split(' · ')[0]+' · local':r.error?'Runtime needs attention':r.phase;
 $('local-model-description').innerHTML=r.vision?'Local language + visual understanding.<br>No external AI API or key.':'Local inference. No external AI API.<br>Vision available in the Qwen3.5 profile.';
 $('desktop-spec').textContent=`Linux · ${r.desktop_type} · ${r.screen.width} × ${r.screen.height}`;
 if(u){$('storage-value').textContent=`${(u.used/1e6).toFixed(1)} / ${Math.round(u.limit/1e6)} MB`;$('storage-fill').style.width=Math.min(100,u.percent)+'%';$('storage-button').classList.toggle('low',u.percent>85);}
 if(r.download&&!r.engine_ready){$('screen-loading').querySelector('span').textContent=`Restoring ${r.download.file}: ${r.download.percent}% · weights stay outside project storage`;$('engine-label').textContent='Restoring cache · '+r.download.percent+'%';}
 if(!r.error&&r.desktop_ready)connectDesktop();
}
function connectDesktop(){
 if(Date.now()<nextStreamTry||desktopPaused||document.hidden||currentTab!=='desktop'||desktopSocket||!state?.runtime.desktop_ready)return;
 const url=new URL('/ws/desktop',location.href);url.protocol=location.protocol==='https:'?'wss:':'ws:';
 const ws=new WebSocket(url);desktopSocket=ws;ws.binaryType='blob';
 ws.onmessage=e=>{if(!(e.data instanceof Blob))return;streamActive=true;lastFrame=Date.now();const old=frameURL;frameURL=URL.createObjectURL(e.data);const img=$('screen-image');img.onload=()=>{$('screen-loading').hidden=true;screenBusy=false;if(old)URL.revokeObjectURL(old);};img.src=frameURL;$('screen-refresh-label').textContent='Live stream';};
 ws.onclose=()=>{if(desktopSocket===ws)desktopSocket=null;streamActive=false;nextStreamTry=Date.now()+6000;$('screen-refresh-label').textContent=desktopPaused?'Paused':'1s fallback';clearTimeout(streamReconnect);if(!desktopPaused&&!document.hidden)streamReconnect=setTimeout(connectDesktop,6000);};
 ws.onerror=()=>ws.close();
}
function closeStream(){clearTimeout(streamReconnect);const s=desktopSocket;desktopSocket=null;streamActive=false;if(s){s.onclose=null;s.close();}}
function refreshScreen(force=false){
 if(desktopPaused||document.hidden||currentTab!=='desktop'||!state?.runtime.desktop_ready)return;
 connectDesktop();if(streamActive||screenBusy)return;
 if(!force&&Date.now()-lastFrame<screenInterval)return;
 screenBusy=true;lastFrame=Date.now();const img=$('screen-image');
 img.onload=()=>{screenBusy=false;$('screen-loading').hidden=true;$('screen-refresh-label').textContent='1s fallback';};
 img.onerror=()=>{screenBusy=false;};img.src='/api/screen?t='+Date.now();
}
function desktopPoint(e){const r=$('screen-image').getBoundingClientRect();const w=state?.runtime.screen.width||1024,h=state?.runtime.screen.height||640;const scale=Math.min(r.width/w,r.height/h);const left=r.left+(r.width-w*scale)/2,top=r.top+(r.height-h*scale)/2;return{x:Math.max(0,Math.min(w-1,Math.round((e.clientX-left)/scale))),y:Math.max(0,Math.min(h-1,Math.round((e.clientY-top)/scale)))};}
$('screen-viewport').addEventListener('pointerdown',e=>{if(!state?.runtime.manual||e.button>2)return;e.preventDefault();$('screen-viewport').focus();$('screen-viewport').setPointerCapture(e.pointerId);dragging=true;sendInput({kind:'down',...desktopPoint(e),button:e.button===2?3:e.button===1?2:1});});
$('screen-viewport').addEventListener('pointermove',e=>{if(!dragging||Date.now()-lastMove<85)return;lastMove=Date.now();sendInput({kind:'move',...desktopPoint(e)});});
$('screen-viewport').addEventListener('pointerup',e=>{if(!dragging)return;dragging=false;sendInput({kind:'up',...desktopPoint(e),button:e.button===2?3:e.button===1?2:1});});
$('screen-viewport').addEventListener('pointercancel',e=>{if(dragging){dragging=false;sendInput({kind:'up',...desktopPoint(e),button:1});}});
$('screen-viewport').addEventListener('contextmenu',e=>{if(state?.runtime.manual)e.preventDefault();});
$('screen-viewport').addEventListener('wheel',e=>{if(!state?.runtime.manual)return;e.preventDefault();sendInput({kind:'click',...desktopPoint(e),button:e.deltaY<0?4:5});},{passive:false});
$('screen-viewport').addEventListener('keydown',e=>{
 if(!state?.runtime.manual)return;
 const base=e.key.toLowerCase();
 if(e.ctrlKey||e.metaKey){if(['a','l','c','v','t','s','o','n','f','w','r','z','y'].includes(base)){e.preventDefault();sendInput({kind:'key',key:'ctrl+'+(e.shiftKey?'shift+':'')+base});}return;}
 if(e.altKey&&['Tab','F4'].includes(e.key)){e.preventDefault();sendInput({kind:'key',key:'alt+'+e.key});return;}
 if(['Enter','Backspace','Tab','Escape','ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Delete','Home','End','PageUp','PageDown','F1','F2','F5','F11'].includes(e.key)){e.preventDefault();sendInput({kind:'key',key:e.key});}
 else if(e.key.length===1){e.preventDefault();sendInput({kind:'text',text:e.key});}
});
$('screen-viewport').addEventListener('paste',e=>{if(!state?.runtime.manual)return;e.preventDefault();const text=e.clipboardData?.getData('text/plain')||'';if(text)sendInput({kind:'text',text:text.slice(0,2000)});});
document.addEventListener('visibilitychange',()=>{if(document.hidden)closeStream();else{connectDesktop();refreshScreen(true);}});

function showSettings(){
 if(!state)return;const r=state.runtime;
 modal('Local intelligence. Real tools.',`<p class="subhead">Your own agent software, built around existing open-weight models. Independent of Grok Bot, xAI, and Cursor. No external AI inference API or user-supplied API key.</p><div class="settings-info"><div class="info-row"><span>Model</span><strong>${escapeHTML(r.model)}</strong></div><div class="info-row"><span>Runtime</span><strong>${r.engine_ready?'Running on local CPU':escapeHTML(r.phase)}</strong></div><div class="info-row"><span>Visual understanding</span><strong>${r.vision?'Enabled · local image model + OCR':'Disabled / still loading'}</strong></div><div class="info-row"><span>Context window</span><strong>${r.context.toLocaleString()} tokens · RAM-conscious</strong></div><div class="info-row"><span>Native desktop</span><strong>Linux · ${escapeHTML(r.desktop_type)} · ${r.screen.width} × ${r.screen.height}</strong></div><div class="info-row"><span>Selected model files</span><strong>${bytes(r.model_cache_bytes)} · excluded cache</strong></div><div class="info-row"><span>Generated tokens this session</span><strong>${r.tokens.toLocaleString()}</strong></div></div><p class="settings-note"><strong>What’s better:</strong> a newer Qwen3.5 0.8B Q5 model, actual image reading, desktop inspection with OCR, native Files/Notes/Terminal apps, HTML website previews, pinned preferences, a source-grounded local knowledge library, answer feedback, and cache restoration at startup.</p><p class="settings-note"><strong>Practical limits:</strong> this 2 GB / 2-core sandbox cannot run the world’s largest models. Small models still make mistakes. The AI uses bounded browser/file/command workflows; it is not an unrestricted visual GUI autopilot. All agents share one computer. Existing pretrained weights—not a foundation model trained from scratch.</p><label for="refresh-rate">Desktop streaming</label><select id="refresh-rate"><option value="live" ${!desktopPaused?'selected':''}>Live · WebSocket, with HTTP fallback</option><option value="paused" ${desktopPaused?'selected':''}>Paused · conserve resources</option></select><p class="settings-note"><strong>Privacy & safety:</strong> inference and image analysis stay on this machine. Visited websites receive normal browsing traffic. AI terminal commands and file replacements require approval. Manual takeover is broader. This is a single-user development app, not isolated multi-user production hosting; it runs only while this service is active. Arena app connections are not inherited.</p><div class="modal-footer"><button id="settings-storage" class="secondary-button">Storage & export</button><button class="primary-button" data-close>Got it</button></div>`,true);
 $('refresh-rate').onchange=e=>{desktopPaused=e.target.value==='paused';if(desktopPaused){closeStream();$('screen-refresh-label').textContent='Paused';}else{connectDesktop();refreshScreen(true);}toast('Desktop streaming updated.');};
 $('settings-storage').onclick=showStorage;
}
function showStorage(){
 if(!state?.storage)return;const u=state.storage,r=state.runtime;
 modal('Room for what matters.',`<p class="subhead">The 128 MB budget applies to the saved project, not to the large, rebuildable model cache.</p><div class="storage-figure">${(u.used/1e6).toFixed(2)} <small>/ ${(u.limit/1e6).toFixed(0)} MB saved</small></div><div class="storage-meter-large"><i style="width:${Math.min(100,u.percent)}%"></i></div><div class="settings-info"><div class="info-row"><span>Remaining saved space</span><strong>${bytes(u.remaining)}</strong></div><div class="info-row"><span>Saved files</span><strong>${u.files.toLocaleString()}</strong></div><div class="info-row"><span>Selected model + vision weights</span><strong>${bytes(r.model_cache_bytes)} · NOT saved in project</strong></div><div class="info-row"><span>Automatic cache restoration</span><strong>Enabled at startup</strong></div></div><p class="settings-note"><strong>How to get more durable storage:</strong> I can’t change Arena’s quota, and no storage-upgrade control has been verified. Use <strong>Arena Workspace → Download</strong> to export the whole project, including your workspace database, then run it on a PC or server with a larger disk. For Arena account/quota options, check <a class="settings-link" href="https://help.arena.ai/" target="_blank" rel="noopener">Arena Help</a>.</p><p class="settings-note"><strong>Keeping this project small:</strong> weights, dependencies, browser cache, and desktop configuration live in excluded caches. App file writes/uploads are budget-checked, with a 3 MB bookkeeping reserve and 2 MB per-file limit. Native/manual filesystem actions are not a hard OS quota—watch this meter. No user files are deleted automatically.</p><div class="modal-footer"><a class="secondary-button" href="/api/export/project" download>${icon('download')}Source ZIP</a><a class="secondary-button" href="/api/agents/${selectedAgent}/export" download>${icon('download')}Agent backup</a><button class="primary-button" data-close>All clear</button></div>`,true);
}
function showProfile(){
 const a=agent();if(!a)return;
 modal('A teammate, shaped by you.',`<p class="subhead">Give ${escapeHTML(a.name)} a clear job and a few preferences. These pinned notes are saved locally and included in future chat tasks. This is contextual memory, not model training.</p><form id="profile-form"><label for="profile-name">Name</label><input id="profile-name" maxlength="32" required value="${escapeHTML(a.name)}"><label for="profile-role">Job / instructions</label><textarea id="profile-role" rows="3" maxlength="500">${escapeHTML(a.role)}</textarea><label for="profile-memory">Pinned memory</label><textarea id="profile-memory" rows="5" maxlength="2000" placeholder="e.g. Prefer short answers. Use Canadian spelling. My project is called…">${escapeHTML(a.memory||'')}</textarea><div class="memory-counter" id="memory-counter">${(a.memory||'').length} / 2000 characters</div><p class="settings-note">You can also say <strong>“Remember that I prefer concise answers.”</strong> Files and conversations remain separate for each agent; the computer and model are shared.</p><div class="modal-footer"><a class="secondary-button" href="/api/agents/${selectedAgent}/export" download>${icon('download')}Back up agent</a><button type="submit" class="primary-button">Save preferences</button></div></form>`);
 $('profile-memory').oninput=e=>$('memory-counter').textContent=e.target.value.length+' / 2000 characters';
 $('profile-form').onsubmit=async e=>{e.preventDefault();try{await api('/api/agents/'+selectedAgent,'PATCH',{name:$('profile-name').value,role:$('profile-role').value,memory:$('profile-memory').value});closeModal();invalidate();await loadState();toast('Agent preferences saved.');}catch(e){toast(e.message,true);}};
}
async function showFile(path){
 try{const f=await api(`/api/file?agent=${selectedAgent}&path=${encodeURIComponent(path)}`);editingFile=path;const src='/preview/'+selectedAgent+'/'+path.split('/').map(encodeURIComponent).join('/');
 modal(escapeHTML(path),`<p class="subhead">${bytes(f.size)} · A real file in ${escapeHTML(agent().name)}’s workspace.${f.truncated?' This view is truncated; download to see the whole file.':''}</p>${f.previewable&&!f.image?'<div class="file-view-toggle"><button id="file-source-toggle" class="active">Source</button><button id="file-preview-toggle">Preview</button></div>':''}${f.image?`<img class="file-image" src="${src}" alt="${escapeHTML(path)}">`:`<label class="sr-only" for="file-editor">File contents</label><textarea class="file-editor" id="file-editor" spellcheck="false" ${!f.editable?'readonly':''}>${escapeHTML(f.content)}</textarea>${f.previewable?`<iframe id="inline-file-preview" class="file-preview" sandbox="allow-scripts" src="${src}" title="Sandboxed file preview" hidden></iframe>`:''}`}<div class="modal-footer"><button class="delete-file" id="delete-file">Delete file</button><a class="secondary-button" href="${downloadUrl(path)}" download>${icon('download')}Download</a>${f.previewable?'<button class="secondary-button" id="preview-on-desktop">'+icon('monitor')+'On desktop</button>':''}${f.editable?'<button class="primary-button" id="save-file">Save changes</button>':''}</div>`,true);
 if(f.editable)$('save-file').onclick=async()=>{try{await api('/api/file','POST',{agent:selectedAgent,path:editingFile,content:$('file-editor').value});toast('Changes saved.');closeModal();await loadState();}catch(e){toast(e.message,true);}};
 if(f.previewable&&!f.image){$('file-source-toggle').onclick=()=>{$('file-editor').hidden=false;$('inline-file-preview').hidden=true;$('file-source-toggle').classList.add('active');$('file-preview-toggle').classList.remove('active');};$('file-preview-toggle').onclick=()=>{$('file-editor').hidden=true;$('inline-file-preview').hidden=false;$('file-source-toggle').classList.remove('active');$('file-preview-toggle').classList.add('active');};}
 if(f.previewable)$('preview-on-desktop').onclick=async()=>{try{await api('/api/file/preview','POST',{agent:selectedAgent,path});closeModal();switchTab('desktop');toast('Actual file opened on the native desktop.');await loadState();}catch(e){toast(e.message,true);}};
 $('delete-file').onclick=async e=>{const b=e.target;if(!b.dataset.confirm){b.dataset.confirm='1';b.textContent='Really delete? Click again';return;}try{await api('/api/file','DELETE',{agent:selectedAgent,path});closeModal();await loadState();toast('File deleted.');}catch(e){toast(e.message,true);}};
 }catch(e){toast(e.message,true);}
}
function showAgentSwitcher(){modal('Choose your teammate.',`<p class="subhead">One computer, separate conversations and files.</p><div class="agent-list">${state.agents.map(a=>`<button class="agent-item" data-agent="${a.id}" data-close><div class="agent-avatar ${a.color}">${icon('orbit')}</div><span><strong>${escapeHTML(a.name)}</strong><small>${escapeHTML(a.role.slice(0,75))}</small></span></button>`).join('')}</div><div class="modal-footer"><button class="primary-button" id="create-from-switcher">Create an agent</button></div>`);$('create-from-switcher').onclick=showNewAgent;}
$('theme-toggle').onclick=()=>{const t=document.documentElement.dataset.theme==='dark'?'light':'dark';document.documentElement.dataset.theme=t;localStorage.setItem('orbit-theme',t);toast(t==='dark'?'Evening mode.':'A little daylight.');};
$('storage-button').onclick=$('storage-mobile').onclick=showStorage;
$('agent-details').onclick=showProfile;
$('agent-switch').onclick=()=>state&&showAgentSwitcher();
$('upload-files').onclick=$('upload-composer').onclick=()=>$('upload-input').click();
$('backup-agent').onclick=()=>{location.href='/api/agents/'+selectedAgent+'/export';};
$('upload-input').onchange=async e=>{const f=e.target.files[0];if(!f)return;try{if(f.size>2_000_000)throw Error('Keep individual uploads under 2 MB.');const data=new FormData();data.append('agent',selectedAgent);data.append('file',f);toast('Saving your attachment locally…');const res=await fetch('/api/upload',{method:'POST',body:data});const d=await res.json();if(!res.ok)throw Error(d.detail||'Upload failed');await loadState();switchTab('files');toast('Uploaded '+f.name+'. Ask the AI to read it.');}catch(err){toast(err.message,true);}finally{e.target.value='';}};
document.addEventListener('click',async e=>{const b=e.target.closest('[data-desktop-app]');if(b){try{const d=await api('/api/desktop/launch','POST',{app:b.dataset.desktopApp,agent:selectedAgent});switchTab('desktop');await loadState();toast('Opened '+d.app+(d.manual?' · AI paused; return control to resume.':''));}catch(err){toast(err.message,true);}}const t=e.target.closest('[data-tab]');if(t){if(t.dataset.tab!=='desktop')closeStream();else connectDesktop();}});

// V3 local knowledge and feedback. No hosted embeddings or automatic weight training.
let libraryAgent='',librarySignature='',libraryLoaded=0,libraryLoading=false;
function renderLibraryStats(){
 const k=state?.knowledge;if(!k)return;
 $('knowledge-count').textContent=k.documents;$('knowledge-nav-count').textContent=k.documents;
 $('library-doc-count').textContent=k.documents;$('library-chunks').textContent=k.chunks;$('library-bytes').textContent=bytes(k.bytes);
 $('feedback-summary').textContent=k.feedback?`${k.helpful} helpful · ${k.needs_work} needs work`:'No feedback saved yet.';
 $('feedback-export').href='/api/feedback/export?agent='+encodeURIComponent(selectedAgent);
 $('knowledge-ask-button').disabled=!k.documents||!state.runtime.engine_ready;
 if(currentTab==='knowledge'&&(libraryAgent!==selectedAgent||Date.now()-libraryLoaded>4000))loadLibrary();
}
async function loadLibrary(force=false){
 if(!selectedAgent||libraryLoading)return;const aid=selectedAgent;libraryLoading=true;
 try{const d=await api('/api/knowledge?agent='+encodeURIComponent(aid));if(aid!==selectedAgent)return;
 libraryAgent=aid;libraryLoaded=Date.now();const sig=JSON.stringify(d.documents);
 if(force||sig!==librarySignature){librarySignature=sig;
 $('knowledge-documents').innerHTML=d.documents.length?d.documents.map(x=>`<div class="knowledge-doc"><span class="knowledge-doc-icon">${icon('file')}</span><div><strong>${escapeHTML(x.name)}</strong><small>${bytes(x.bytes)} · ${x.chunks} chunks · ${new Date(x.created*1000).toLocaleDateString()}</small></div><a href="/api/knowledge/${x.id}/download?agent=${encodeURIComponent(aid)}" download title="Download original source">${icon('download')}</a><button data-remove-document="${x.id}" title="Remove from library">${icon('close')}</button></div>`).join(''):`<div class="library-empty">${icon('book')}<strong>A little context goes a long way.</strong><p>Add a reference document, then ask a question.<br>Start with clear, trustworthy project notes.</p><button class="small-button" data-add-knowledge>Add your first document ↗</button></div>`;
 }
 $('library-status').textContent='Indexed locally · no external API';
 }catch(e){$('library-status').textContent='Unable to load library';toast(e.message,true);}finally{libraryLoading=false;}
}
function showFeedback(message,score){
 if(score===1){api('/api/feedback','POST',{agent:selectedAgent,message,score,correction:''}).then(()=>{toast('Helpful rating saved locally.');loadState();}).catch(e=>toast(e.message,true));return;}
 modal('A better answer starts here.',`<p class="subhead">What went wrong? Save a specific correction for later review. This does not silently retrain the model.</p><form id="feedback-form"><label for="feedback-correction">Your correction / expected answer</label><textarea id="feedback-correction" maxlength="2000" rows="6" placeholder="The correct launch date is… The answer should quote…"></textarea><p class="settings-note">For facts the AI should use immediately, add the source to <strong>Library</strong>. For an enduring preference, edit <strong>pinned memory</strong>.</p><div class="modal-footer"><button type="button" class="secondary-button" data-close>Cancel</button><button type="submit" class="primary-button">Save feedback</button></div></form>`);
 $('feedback-form').onsubmit=async e=>{e.preventDefault();try{await api('/api/feedback','POST',{agent:selectedAgent,message,score,correction:$('feedback-correction').value});closeModal();await loadState();toast('Correction saved locally for review.');}catch(err){toast(err.message,true);}};
}
$('knowledge-upload').onclick=()=>$('knowledge-upload-input').click();
$('knowledge-upload-input').onchange=async e=>{const file=e.target.files[0];if(!file)return;try{if(file.size>2_000_000)throw Error('Keep knowledge documents under 2 MB each.');const data=new FormData();data.append('agent',selectedAgent);data.append('file',file);$('library-status').textContent='Indexing your source…';toast('Indexing locally. No document goes to an external AI provider.');const res=await fetch('/api/knowledge/upload',{method:'POST',body:data});const doc=await res.json();if(!res.ok)throw Error(doc.detail||'Indexing failed');libraryLoaded=0;await loadState();await loadLibrary(true);toast(doc.name+' is now searchable.');}catch(err){toast(err.message,true);}finally{e.target.value='';}};
$('knowledge-ask').onsubmit=async e=>{e.preventDefault();const q=$('knowledge-question').value.trim();if(!q)return;$('prompt').value='Use my knowledge library to answer: '+q;updateSend();await sendTask();$('knowledge-question').value='';};
$('knowledge-search-form').onsubmit=async e=>{e.preventDefault();const q=$('knowledge-search').value.trim();const target=$('knowledge-search-results');if(!q){target.hidden=true;return;}try{const r=await api('/api/knowledge/search?agent='+encodeURIComponent(selectedAgent)+'&q='+encodeURIComponent(q));target.hidden=false;target.innerHTML=r.hits.length?r.hits.map(x=>`<article><strong>${escapeHTML(x.name)}</strong><p>${escapeHTML(x.content.slice(0,430))}${x.content.length>430?'…':''}</p><a href="/api/knowledge/${x.doc_id}/download?agent=${encodeURIComponent(selectedAgent)}" download>Open the original ↗</a></article>`).join(''):'<p>No matching source text. Try a keyword or add a relevant document.</p>';}catch(err){toast(err.message,true);}};
document.addEventListener('click',async e=>{
 const add=e.target.closest('[data-add-knowledge]');if(add)$('knowledge-upload-input').click();
 const tab=e.target.closest('[data-tab="knowledge"], [data-nav="knowledge"]');if(tab)loadLibrary();
 const feedback=e.target.closest('[data-feedback]');if(feedback)showFeedback(feedback.dataset.feedback,Number(feedback.dataset.score));
 const remove=e.target.closest('[data-remove-document]');if(remove){if(!remove.dataset.confirm){remove.dataset.confirm='1';remove.innerHTML='Remove?';remove.title='Click again to remove this library-owned source and its index';return;}try{await api('/api/knowledge/'+remove.dataset.removeDocument+'?agent='+encodeURIComponent(selectedAgent),'DELETE');libraryLoaded=0;await loadState();await loadLibrary(true);toast('Library source removed. Other files were not changed.');}catch(err){toast(err.message,true);}}
});
function routeHash(){const t=location.hash.slice(1);if(['desktop','files','knowledge','terminal'].includes(t)){switchTab(t);if(t==='knowledge')loadLibrary();}}
window.addEventListener('hashchange',routeHash);routeHash();

$('owner-logout').onclick=async()=>{try{await api('/api/auth/logout','POST',{});location.href='/';}catch(e){toast(e.message,true);}};
