'use strict';
const menu=document.getElementById('menu');
if(menu)menu.onclick=()=>{const open=document.querySelector('.site-header').classList.toggle('menu-open');menu.setAttribute('aria-expanded',String(open));};
document.querySelectorAll('.site-header nav a').forEach(a=>a.addEventListener('click',()=>{document.querySelector('.site-header').classList.remove('menu-open');menu?.setAttribute('aria-expanded','false');}));
async function runtimeStatus(){
 const text=document.getElementById('runtime-text'),dot=document.getElementById('runtime-dot');if(!text)return;
 try{const res=await fetch('/api/site');if(!res.ok)return;const s=await res.json();text.textContent=s.engine_ready?s.model+' · local '+(s.vision?'language + vision':'inference'):s.phase+' · your workspace opens while the engine loads';dot?.classList.toggle('ready',s.engine_ready);}catch{text.textContent='Local-first AI · open the workspace to check runtime status';}
}
runtimeStatus();setInterval(runtimeStatus,7000);
