"""Saved-workspace budget. Model/OS/dependency caches are deliberately separate."""
import os
import time
from pathlib import Path

PROJECT = Path(__file__).resolve().parent.parent
ACCOUNT_ROOT = Path(os.environ.get('ORBIT_STORAGE_ROOT', str(Path.home() if os.environ.get('E2B_SANDBOX_ID') else PROJECT)))
LIMIT = int(float(os.environ.get('ORBIT_PROJECT_LIMIT_MB', '128')) * 1_000_000)
RESERVE = min(3_000_000, LIMIT // 20)
EXCLUDED = {'.arena', '.cache', '.local', '.mypy_cache', '.next', '.nox', '.npm', '.nuxt', '.output', '.parcel-cache', '.pytest_cache', '.ruff_cache', '.svelte-kit', '.tox', '.turbo', '.venv', '.vite', '__pycache__', 'build', 'coverage', 'dist', 'node_modules', 'out', 'target'}
_cached = None
_stamp = 0


def usage(refresh=False):
    global _cached, _stamp
    if not refresh and _cached is not None and time.monotonic() - _stamp < 4:
        return _cached
    total = count = artifacts = 0
    workspace = PROJECT / 'workspace'
    for root, dirs, files in os.walk(ACCOUNT_ROOT):
        dirs[:] = [d for d in dirs if d not in EXCLUDED and not Path(root, d).is_symlink()]
        for name in files:
            p = Path(root, name)
            if name in {'.netrc', '.git-credentials'} or (p.parent.name == '.git' and name in {'config', 'credentials'}):
                continue
            try:
                if p.is_symlink():
                    continue
                n = p.stat().st_size
                total += n
                count += 1
                if workspace in p.parents and not name.startswith('.'):
                    artifacts += n
            except OSError:
                pass
    _cached = dict(used=total, limit=LIMIT, remaining=max(0, LIMIT - total), reserved=RESERVE,
                   percent=round(total / max(1, LIMIT) * 100, 2), files=count, artifact_bytes=artifacts,
                   scope='Saved project and workspace files; temporary model/dependency caches excluded',
                   model_cache_persistent=False)
    _stamp = time.monotonic()
    return _cached


def require(additional=0, refresh=True):
    u = usage(refresh)
    if u['used'] + max(0, additional) > LIMIT - RESERVE:
        raise ValueError('Saved-project storage is nearly full. Download and remove unneeded files, or export the project to a machine with more storage. The model cache is separate.')
    if u['files'] >= 9500:
        raise ValueError('The saved workspace is near its file-count limit. Export or remove unneeded files first.')


def written():
    global _stamp
    _stamp = 0
