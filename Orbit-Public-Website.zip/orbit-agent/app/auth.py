"""Single-owner login for deployment. No credentials in source or user chats.
This is defense in depth, not multi-tenant computer isolation.
"""
import base64
import hashlib
import hmac
import json
import os
import secrets
import time
from urllib.parse import urlparse

REQUIRED = os.environ.get('ORBIT_AUTH_REQUIRED', '0') == '1'
PASSWORD_HASH = os.environ.get('ORBIT_PASSWORD_HASH', '')
SESSION_SECRET = os.environ.get('ORBIT_SESSION_SECRET', '')
COOKIE = 'orbit_owner'
DESKTOP_COOKIE = 'orbit_desktop'
DESKTOP_TOKEN = secrets.token_urlsafe(32)
TTL = 8 * 3600
_attempts = {}


def b64(data):
    return base64.urlsafe_b64encode(data).decode().rstrip('=')


def unb64(data):
    return base64.urlsafe_b64decode(data + '=' * (-len(data) % 4))


def password_hash(password, salt=None):
    salt = salt or secrets.token_bytes(16)
    rounds = 600000
    digest = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, rounds)
    return f'pbkdf2_sha256${rounds}${b64(salt)}${b64(digest)}'


def configured():
    try:
        kind, rounds, salt, digest = PASSWORD_HASH.split('$')
        return kind == 'pbkdf2_sha256' and 100000 <= int(rounds) <= 1000000 and len(unb64(salt)) >= 16 and len(unb64(digest)) == 32 and len(SESSION_SECRET) >= 32
    except Exception:
        return False


def verify_password(password):
    if not configured() or len(password) > 512:
        return False
    _, rounds, salt, digest = PASSWORD_HASH.split('$')
    got = hashlib.pbkdf2_hmac('sha256', password.encode(), unb64(salt), int(rounds))
    return hmac.compare_digest(got, unb64(digest))


def issue_session():
    payload = b64(json.dumps({'exp': int(time.time()) + TTL, 'v': hashlib.sha256(PASSWORD_HASH.encode()).hexdigest()[:16], 'n': secrets.token_hex(8)}, separators=(',', ':')).encode())
    sig = b64(hmac.new(SESSION_SECRET.encode(), payload.encode(), hashlib.sha256).digest())
    return payload + '.' + sig


def valid_session(token):
    if not configured() or not token or len(token) > 1000:
        return False
    try:
        payload, signature = token.split('.')
        expected = b64(hmac.new(SESSION_SECRET.encode(), payload.encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(signature, expected):
            return False
        data = json.loads(unb64(payload))
        return int(data['exp']) > time.time() and data['v'] == hashlib.sha256(PASSWORD_HASH.encode()).hexdigest()[:16]
    except (ValueError, KeyError, TypeError):
        return False


def authenticated(request):
    return not REQUIRED or valid_session(request.cookies.get(COOKIE, ''))


def desktop_bridge(request):
    allowed = {'/desktop-home', '/api/desktop/meta', '/api/desktop/launch'}
    if (request.url.path not in allowed and not request.url.path.startswith('/preview/')) or not request.client or request.client.host not in {'127.0.0.1', '::1'}:
        return False
    u = urlparse(str(request.url))
    if u.hostname not in {'127.0.0.1', 'localhost', '::1'}:
        return False
    token = request.headers.get('x-orbit-desktop-token') or request.cookies.get(DESKTOP_COOKIE, '')
    return bool(token) and hmac.compare_digest(token, DESKTOP_TOKEN)


def public_request(request):
    path = request.url.path
    return (request.method in {'GET', 'HEAD'} and (path in {'/', '/guide', '/login', '/api/site', '/api/auth/status', '/api/export/project'} or path.startswith('/static/'))) or (request.method == 'POST' and path == '/api/auth/login')


def login_allowed(key):
    now = time.time()
    if len(_attempts) > 2048:
        for ip in list(_attempts):
            if not _attempts[ip] or now - max(_attempts[ip]) > 600:
                _attempts.pop(ip, None)
    times = [x for x in _attempts.get(key, []) if now - x < 600]
    _attempts[key] = times
    if len(times) >= 8:
        return False
    times.append(now)
    return True


def clear_attempts(key):
    _attempts.pop(key, None)
