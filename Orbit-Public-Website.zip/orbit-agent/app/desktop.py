"""Rebuildable XFCE desktop configuration and native launchers."""
import os
import shutil
import sys
from pathlib import Path
from xml.sax.saxutils import escape

ROOT = Path(__file__).resolve().parent.parent
SCREEN = {'width': 1024, 'height': 640}


def prepare(cache):
    base = cache / 'desktop'
    config = base / 'config'
    data = base / 'data'
    xml = config / 'xfce4/xfconf/xfce-perchannel-xml'
    xml.mkdir(parents=True, exist_ok=True)
    desktop = base / 'Desktop'
    desktop.mkdir(exist_ok=True)
    env = {**os.environ, 'DISPLAY': ':97', 'XDG_CONFIG_HOME': str(config), 'XDG_DATA_HOME': str(data), 'XDG_CACHE_HOME': str(base / 'cache')}
    dirs = config / 'user-dirs.dirs'
    dirs.write_text(f'XDG_DESKTOP_DIR="{desktop}"\nXDG_DOCUMENTS_DIR="{ROOT / "workspace"}"\nXDG_DOWNLOAD_DIR="{base / "Downloads"}"\n')
    (base / 'Downloads').mkdir(exist_ok=True)
    gtk = config / 'gtk-3.0'
    gtk.mkdir(exist_ok=True)
    (gtk / 'settings.ini').write_text('[Settings]\ngtk-theme-name=Adwaita\ngtk-icon-theme-name=Adwaita\ngtk-font-name=DejaVu Sans 12\ngtk-application-prefer-dark-theme=0\n')
    (xml / 'xsettings.xml').write_text('''<?xml version="1.0" encoding="UTF-8"?>
<channel name="xsettings" version="1.0"><property name="Net" type="empty"><property name="ThemeName" type="string" value="Adwaita"/><property name="IconThemeName" type="string" value="Adwaita"/></property><property name="Gtk" type="empty"><property name="FontName" type="string" value="DejaVu Sans 12"/><property name="MonospaceFontName" type="string" value="DejaVu Sans Mono 11"/><property name="ApplicationPreferDarkTheme" type="bool" value="false"/></property><property name="Xft" type="empty"><property name="DPI" type="int" value="96"/><property name="Antialias" type="int" value="1"/></property></channel>''')
    (xml / 'xfwm4.xml').write_text('''<?xml version="1.0" encoding="UTF-8"?>
<channel name="xfwm4" version="1.0"><property name="general" type="empty"><property name="theme" type="string" value="Default"/><property name="title_font" type="string" value="DejaVu Sans Bold 10"/><property name="button_layout" type="string" value="O|HMC"/><property name="click_to_focus" type="bool" value="true"/><property name="use_compositing" type="bool" value="false"/><property name="workspace_count" type="int" value="1"/><property name="wrap_workspaces" type="bool" value="false"/><property name="snap_to_windows" type="bool" value="true"/><property name="snap_width" type="int" value="12"/></property></channel>''')
    wallpaper = escape(str(ROOT / 'app/static/wallpaper.png'))
    monitor_nodes = ''.join(f'<property name="{m}" type="empty"><property name="workspace0" type="empty"><property name="last-image" type="string" value="{wallpaper}"/><property name="image-style" type="int" value="5"/><property name="color-style" type="int" value="0"/></property></property>' for m in ['monitor0', 'monitorscreen', 'monitordefault', 'monitorVirtual-0'])
    (xml / 'xfce4-desktop.xml').write_text(f'''<?xml version="1.0" encoding="UTF-8"?><channel name="xfce4-desktop" version="1.0"><property name="backdrop" type="empty"><property name="screen0" type="empty">{monitor_nodes}</property></property><property name="desktop-icons" type="empty"><property name="style" type="int" value="2"/><property name="icon-size" type="uint" value="48"/><property name="font-size" type="double" value="12"/><property name="use-custom-font-size" type="bool" value="true"/><property name="file-icons" type="empty"><property name="show-home" type="bool" value="false"/><property name="show-filesystem" type="bool" value="false"/><property name="show-trash" type="bool" value="false"/><property name="show-removable" type="bool" value="false"/></property></property></channel>''')
    apps = [('browser', 'Browser', 'web-browser', 'A real Chromium browser'), ('files', 'Workspace', 'folder-documents', 'Files for the selected agent'), ('notes', 'Notes', 'accessories-text-editor', 'A real text editor'), ('terminal', 'Terminal', 'utilities-terminal', 'A real terminal on this computer')]
    plugins = config / 'xfce4/panel'
    for i, (key, name, ic, comment) in enumerate(apps, 2):
        p = plugins / f'launcher-{i}'
        p.mkdir(parents=True, exist_ok=True)
        entry = f'[Desktop Entry]\nVersion=1.0\nType=Application\nName={name}\nComment={comment}\nIcon={ic}\nExec={sys.executable} {ROOT / "native_open.py"} {key}\nTerminal=false\nStartupNotify=false\n'
        (p / 'orbit.desktop').write_text(entry)
        (p / 'orbit.desktop').chmod(0o755)
        shortcut = desktop / f'{name}.desktop'
        shortcut.write_text(entry)
        shortcut.chmod(0o755)
    launcher_xml = ''.join(f'<property name="plugin-{i}" type="string" value="launcher"><property name="items" type="array"><value type="string" value="orbit.desktop"/></property></property>' for i in range(2, 6))
    (xml / 'xfce4-panel.xml').write_text(f'''<?xml version="1.0" encoding="UTF-8"?><channel name="xfce4-panel" version="1.0"><property name="configver" type="int" value="2"/><property name="panels" type="array"><value type="int" value="1"/><property name="panel-1" type="empty"><property name="position" type="string" value="p=6;x=512;y=18"/><property name="position-locked" type="bool" value="true"/><property name="size" type="uint" value="38"/><property name="length" type="double" value="100"/><property name="length-adjust" type="bool" value="false"/><property name="mode" type="uint" value="0"/><property name="background-style" type="uint" value="0"/><property name="plugin-ids" type="array">{''.join(f'<value type="int" value="{i}"/>' for i in [1, 2, 3, 4, 5, 6, 7])}</property></property></property><property name="plugins" type="empty"><property name="plugin-1" type="string" value="showdesktop"/>{launcher_xml}<property name="plugin-6" type="string" value="tasklist"><property name="show-handle" type="bool" value="false"/><property name="show-labels" type="bool" value="true"/><property name="flat-buttons" type="bool" value="true"/></property><property name="plugin-7" type="string" value="clock"><property name="digital-format" type="string" value="%H:%M"/></property></property></channel>''')
    return env


def available():
    return all(shutil.which(x) for x in ['xfwm4', 'xfce4-panel', 'xfdesktop', 'dbus-daemon', 'thunar', 'mousepad'])
