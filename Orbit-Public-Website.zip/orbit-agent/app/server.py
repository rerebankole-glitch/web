"""Browser dashboard for a single-user local desktop agent."""
import asyncio
import io
import os
import subprocess
from contextlib import asynccontextmanager
from pathlib import Path
from urllib.parse import urlparse

import mss
from PIL import Image
from fastapi import FastAPI, Request, HTTPException, WebSocket, WebSocketDisconnect, UploadFile, File, Form
from fastapi.responses import FileResponse, Response, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import store, storage, knowledge, auth
from .runtime import runtime

HERE = Path(__file__).resolve().parent


@asynccontextmanager
async def lifespan(app):
    store.init()
    knowledge.init()
    boot = asyncio.create_task(runtime.boot())
    yield
    boot.cancel()
    await runtime.close()


app = FastAPI(title='Orbit Desktop Agent', lifespan=lifespan, docs_url=None, redoc_url=None)


@app.middleware('http')
async def same_origin(request: Request, call_next):
    if request.method not in ('GET', 'HEAD', 'OPTIONS'):
        origin = request.headers.get('origin')
        hosts = {request.headers.get('host'), request.headers.get('x-forwarded-host')}
        if origin and urlparse(origin).netloc not in hosts:
            return JSONResponse({'detail': 'Only requests from this dashboard are allowed.'}, status_code=403)
    try:
        response = await call_next(request)
        response.headers['X-Content-Type-Options'] = 'nosniff'
        return response
    except ValueError as e:
        return JSONResponse({'detail': str(e)}, status_code=400)


class TaskInput(BaseModel):
    agent: str
    prompt: str = Field(min_length=1, max_length=4000)


class AgentInput(BaseModel):
    name: str = Field(min_length=1, max_length=32)
    role: str = Field(default='A careful general-purpose desktop agent.', max_length=500)
    color: str = 'sage'


class Decision(BaseModel):
    approved: bool


class Control(BaseModel):
    active: bool


class Input(BaseModel):
    kind: str
    x: int = 0
    y: int = 0
    button: int = 1
    text: str = Field(default='', max_length=2000)
    key: str = ''


class Navigate(BaseModel):
    url: str


class Terminal(BaseModel):
    agent: str
    command: str = Field(min_length=1, max_length=500)


class FileInput(BaseModel):
    agent: str
    path: str
    content: str = Field(max_length=2_000_000)


def checked_agent(aid):
    try:
        return store.agent(aid)
    except ValueError:
        raise HTTPException(404, 'Agent not found')


@app.get('/')
async def index():
    return FileResponse(HERE / 'static/site.html')


@app.get('/desktop-home')
async def home():
    return FileResponse(HERE / 'static/desktop.html')


@app.get('/api/state')
async def state(agent: str = ''):
    agents = store.agents()
    if not agent and agents:
        agent = agents[0]['id']
    checked_agent(agent)
    tasks = store.tasks()
    for a in agents:
        t = next((t for t in tasks if t['agent'] == a['id'] and t['state'] in ('queued', 'running', 'waiting', 'paused')), None)
        a['status'] = t['state'] if t else 'idle'
    approvals = [{k: v for k, v in a.items() if k != 'future'} for a in runtime.approvals.values() if a['agent'] == agent]
    return dict(agents=agents, selected=agent, messages=store.messages(agent), tasks=[t for t in tasks if t['agent'] == agent],
                events=store.events(agent), files=store.files(agent), runtime=runtime.status(), approvals=approvals,
                terminal=runtime.terminal_history[-15:], storage=storage.usage(), knowledge=knowledge.summary(agent), auth_required=auth.REQUIRED)


@app.get('/api/activity')
async def activity():
    return {'events': store.events(), 'tasks': store.tasks()}


@app.post('/api/agents')
async def create_agent(body: AgentInput):
    color = body.color if body.color in ('sage', 'clay', 'blue', 'lilac') else 'sage'
    a = store.add_agent(body.name, body.role, color)
    store.message(a['id'], 'assistant', f'I’m {a["name"]}. {a["role"]}\n\nI work on the shared sandbox computer, with my own files and conversation. What should I work on first?')
    return a


@app.post('/api/tasks')
async def task(body: TaskInput):
    checked_agent(body.agent)
    if not runtime.engine_ready:
        raise HTTPException(503, 'The local model is still loading. Please try in a moment.')
    if len(runtime.jobs) >= 5:
        raise HTTPException(429, 'There are already five queued tasks. Wait or stop one first.')
    storage.require(32000)
    store.message(body.agent, 'user', body.prompt.strip())
    t = store.new_task(body.agent, body.prompt.strip())
    runtime.start_task(t)
    return t


@app.post('/api/tasks/{task_id}/stop')
async def stop(task_id: str):
    job = runtime.jobs.get(task_id)
    if not job:
        raise HTTPException(404, 'This task is no longer running')
    job.cancel()
    runtime.jobs.pop(task_id, None)
    store.task_state(task_id, 'stopped', 'Stopped by you.')
    return {'ok': True}


@app.post('/api/approvals/{approval_id}')
async def approval(approval_id: str, body: Decision):
    a = runtime.approvals.get(approval_id)
    if not a or a['future'].done():
        raise HTTPException(404, 'This approval is no longer pending')
    a['future'].set_result(body.approved)
    return {'ok': True}


@app.post('/api/control')
async def control(body: Control):
    runtime.manual = body.active
    return {'manual': runtime.manual}


def capture_screen():
    with mss.mss(display=':97') as s:
        shot = s.grab(s.monitors[0])
        im = Image.frombytes('RGB', shot.size, shot.bgra, 'raw', 'BGRX')
        buf = io.BytesIO()
        im.save(buf, format='JPEG', quality=83, optimize=False)
        return buf.getvalue()


@app.get('/api/screen')
async def screen():
    if not runtime.desktop_ready:
        raise HTTPException(503, 'The desktop is starting')
    try:
        data = await asyncio.to_thread(capture_screen)
        return Response(data, media_type='image/jpeg', headers={'Cache-Control': 'no-store'})
    except Exception:
        raise HTTPException(503, 'Could not capture the desktop')


@app.post('/api/input')
async def desktop_input(body: Input):
    if not runtime.manual:
        raise HTTPException(409, 'Take control of the computer first')
    env = {**os.environ, 'DISPLAY': ':97'}
    if body.kind == 'click':
        args = ['xdotool', 'mousemove', str(max(0, min(runtime.screen['width'] - 1, body.x))), str(max(0, min(runtime.screen['height'] - 1, body.y))), 'click', str(body.button if body.button in (1, 2, 3, 4, 5) else 1)]
    elif body.kind in {'down', 'move', 'up'}:
        x = str(max(0, min(runtime.screen['width'] - 1, body.x)))
        y = str(max(0, min(runtime.screen['height'] - 1, body.y)))
        args = ['xdotool', 'mousemove', x, y]
        if body.kind != 'move':
            if body.kind == 'up':
                args += ['sleep', '0.04']  # Let the real WM process the final drag motion before release.
            args += ['mousedown' if body.kind == 'down' else 'mouseup', str(body.button if body.button in (1, 2, 3) else 1)]
    elif body.kind == 'text':
        args = ['xdotool', 'type', '--clearmodifiers', '--delay', '1', '--', body.text]
    elif body.kind == 'key':
        keys = {'Enter': 'Return', 'Backspace': 'BackSpace', 'Tab': 'Tab', 'Escape': 'Escape', 'ArrowLeft': 'Left', 'ArrowRight': 'Right', 'ArrowUp': 'Up', 'ArrowDown': 'Down', 'Delete': 'Delete', 'Home': 'Home', 'End': 'End', 'PageUp': 'Prior', 'PageDown': 'Next', 'ctrl+a': 'ctrl+a', 'ctrl+l': 'ctrl+l', 'ctrl+c': 'ctrl+c', 'ctrl+v': 'ctrl+v', 'ctrl+t': 'ctrl+t'}
        keys.update({k: k for k in ['ctrl+s', 'ctrl+o', 'ctrl+n', 'ctrl+f', 'ctrl+w', 'ctrl+r', 'ctrl+z', 'ctrl+y', 'ctrl+shift+s', 'ctrl+shift+z', 'ctrl+shift+c', 'ctrl+shift+v', 'ctrl+shift+t', 'ctrl+shift+w', 'ctrl+alt+d', 'alt+Tab', 'alt+F4', 'F1', 'F2', 'F5', 'F11']})
        if body.key not in keys:
            raise HTTPException(400, 'This key is not supported')
        args = ['xdotool', 'key', '--clearmodifiers', keys[body.key]]
    else:
        raise HTTPException(400, 'Unknown input type')
    p = await asyncio.create_subprocess_exec(*args, env=env, stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL)
    await p.wait()
    return {'ok': True}


@app.post('/api/browser/open')
async def open_browser(body: Navigate):
    if runtime.active_task and not runtime.manual:
        raise HTTPException(409, 'Take control or let the agent finish before navigating')
    if not runtime.desktop_ready:
        raise HTTPException(503, 'The desktop is starting')
    title = await runtime.navigate(body.url)
    return {'title': title, 'url': runtime.page.url}


@app.post('/api/browser/home')
async def browser_home():
    if runtime.active_task and not runtime.manual:
        raise HTTPException(409, 'Take control or let the agent finish first')
    await runtime.focus_browser()
    await runtime.context.unroute('**/*')
    await runtime.page.goto(f'http://127.0.0.1:{os.environ.get("PORT", "3000")}/desktop-home')
    return {'ok': True}


@app.post('/api/terminal')
async def terminal(body: Terminal):
    checked_agent(body.agent)
    if runtime.active_task and not runtime.manual:
        raise HTTPException(409, 'Let the agent finish or take control first')
    # A user's explicit Run button is their approval. Agent-issued commands have a separate gate.
    rec = await runtime.terminal(body.command, body.agent)
    store.event(body.agent, '', 'terminal', 'You ran a terminal command', f'$ {body.command}\n{rec["output"]}')
    return rec


@app.get('/api/file')
async def get_file(agent: str, path: str):
    checked_agent(agent)
    p = store.safe_path(agent, path)
    if not p.is_file():
        raise HTTPException(404, 'File not found')
    size = p.stat().st_size
    image = p.suffix.lower() in {'.png', '.jpg', '.jpeg', '.webp'}
    content = '' if image else p.read_bytes()[:250000].decode('utf-8', errors='replace')
    return {'name': path, 'content': content, 'size': size, 'image': image, 'editable': not image and size <= 250000 and not path.startswith('knowledge/'), 'truncated': not image and size > 250000, 'previewable': p.suffix.lower() in {'.html', '.htm', '.svg', '.png', '.jpg', '.jpeg', '.webp'}}


@app.get('/api/file/download')
async def download(agent: str, path: str):
    checked_agent(agent)
    p = store.safe_path(agent, path)
    if not p.is_file():
        raise HTTPException(404, 'File not found')
    return FileResponse(p, filename=p.name, media_type='application/octet-stream')


@app.post('/api/file')
async def save_file(body: FileInput):
    checked_agent(body.agent)
    if body.path.startswith('knowledge/'):
        raise HTTPException(400, 'Library sources are managed in Library. Remove and re-upload a revised document to update its index.')
    p = store.safe_path(body.agent, body.path)
    size = len(body.content.encode())
    if size > 2_000_000:
        raise HTTPException(413, 'Keep individual files under 2 MB')
    storage.require(max(0, size - (p.stat().st_size if p.exists() else 0)))
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(body.content, encoding='utf-8')
    storage.written()
    store.event(body.agent, '', 'file', f'You saved {body.path}', f'{len(body.content.encode()):,} bytes')
    return {'ok': True}


@app.get('/api/health')
async def health():
    return runtime.status()


app.mount('/static', StaticFiles(directory=HERE / 'static'), name='static')


class AgentPatch(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=32)
    role: str | None = Field(default=None, max_length=500)
    memory: str | None = Field(default=None, max_length=2000)


class DesktopLaunch(BaseModel):
    app: str
    agent: str = ''


class FileReference(BaseModel):
    agent: str
    path: str = Field(max_length=160)


@app.patch('/api/agents/{agent_id}')
async def edit_agent(agent_id: str, body: AgentPatch):
    checked_agent(agent_id)
    storage.require(8192)
    return store.update_agent(agent_id, **{k: v for k, v in body.model_dump(exclude_unset=True).items() if v is not None})


@app.get('/api/storage')
async def storage_status():
    return storage.usage()


@app.get('/api/desktop/meta')
async def desktop_meta():
    aid = runtime.selected_agent or store.agents()[0]['id']
    a = checked_agent(aid)
    return {'agent': {'name': a['name'], 'id': a['id'], 'role': a['role']}, 'runtime': runtime.status(), 'storage': storage.usage(), 'files': len(store.files(aid))}


@app.post('/api/desktop/launch')
async def launch_app(body: DesktopLaunch):
    if body.agent:
        checked_agent(body.agent)
        runtime.selected_agent = body.agent
    if runtime.active_task:
        runtime.manual = True  # Human app-switching is an explicit takeover.
    label = await runtime.launch_app(body.app, body.agent or None)
    return {'ok': True, 'app': label, 'manual': runtime.manual}


@app.post('/api/file/preview')
async def preview_file(body: FileReference):
    checked_agent(body.agent)
    if runtime.active_task and not runtime.manual:
        raise HTTPException(409, 'Let the agent finish or take control first')
    title = await runtime.open_artifact(body.agent, body.path)
    return {'ok': True, 'title': title, 'url': runtime.page.url}


@app.get('/preview/{agent_id}/{filename:path}')
async def artifact(agent_id: str, filename: str):
    checked_agent(agent_id)
    p = store.safe_path(agent_id, filename)
    if not p.is_file() or p.suffix.lower() not in {'.html', '.htm', '.svg', '.png', '.jpg', '.jpeg', '.webp'}:
        raise HTTPException(404, 'Preview file not found')
    return FileResponse(p, headers={
        'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; img-src data: blob:; font-src data:; base-uri 'none'; form-action 'none'; frame-ancestors 'self'; sandbox allow-scripts",
        'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff'})


@app.post('/api/upload')
async def upload(agent: str = Form(...), file: UploadFile = File(...)):
    checked_agent(agent)
    name = Path(file.filename or '').name
    if not name or name.startswith('.') or len(name) > 160:
        raise HTTPException(400, 'Choose a normal filename under 160 characters')
    if Path(name).suffix.lower() not in {'.md', '.txt', '.html', '.htm', '.css', '.js', '.py', '.json', '.csv', '.svg', '.png', '.jpg', '.jpeg', '.webp'}:
        raise HTTPException(400, 'Upload text, code, HTML, SVG, PNG, JPEG, or WebP files')
    content = await file.read(2_000_001)
    await file.close()
    if len(content) > 2_000_000:
        raise HTTPException(413, 'Keep individual uploads under 2 MB')
    p = store.safe_path(agent, name)
    if p.exists():
        raise HTTPException(409, 'That filename already exists. Rename the upload or edit the existing file.')
    storage.require(len(content))
    p.write_bytes(content)
    storage.written()
    store.event(agent, '', 'file', f'You uploaded {name}', f'{len(content):,} bytes; stored locally.')
    return {'ok': True, 'path': name, 'size': len(content)}


@app.delete('/api/file')
async def delete_file(body: FileReference):
    checked_agent(body.agent)
    if body.path.startswith('knowledge/'):
        raise HTTPException(400, 'Remove a library-owned source in Library, so its index is removed too.')
    if runtime.active_task and not runtime.manual:
        raise HTTPException(409, 'Let the agent finish or take control first')
    p = store.safe_path(body.agent, body.path)
    if not p.is_file():
        raise HTTPException(404, 'File not found')
    p.unlink()
    storage.written()
    store.event(body.agent, '', 'file', f'You deleted {body.path}', 'Explicitly deleted from the Files panel.')
    return {'ok': True}


def build_agent_backup(agent_id):
    import json
    import uuid
    import zipfile
    from .runtime import CACHE
    a = store.agent(agent_id)
    root = store.agent_dir(agent_id).resolve()
    folder = CACHE / 'exports'
    folder.mkdir(parents=True, exist_ok=True)
    dest = folder / (uuid.uuid4().hex + '.zip')
    with zipfile.ZipFile(dest, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('agent.json', json.dumps(a, indent=2))
        z.writestr('knowledge-documents.json', json.dumps(knowledge.documents(agent_id), indent=2))
        with store.connect() as db:
            for table, name in [('messages', 'conversation.ndjson'), ('tasks', 'tasks.ndjson'), ('events', 'activity.ndjson'), ('answer_feedback', 'feedback.ndjson')]:
                with z.open(name, 'w') as f:
                    for row in db.execute(f'SELECT * FROM {table} WHERE agent=? ORDER BY created', (agent_id,)):
                        f.write((json.dumps(dict(row), ensure_ascii=False) + '\n').encode())
        for p in root.rglob('*'):
            resolved = p.resolve()
            if p.is_file() and not p.is_symlink() and root in resolved.parents and not any(part.startswith('.') for part in p.relative_to(root).parts):
                z.write(p, 'files/' + p.relative_to(root).as_posix())
    return dest, a


@app.get('/api/agents/{agent_id}/export')
async def export_agent(agent_id: str):
    import re
    from starlette.background import BackgroundTask
    checked_agent(agent_id)
    dest, a = await asyncio.to_thread(build_agent_backup, agent_id)
    safe_name = re.sub(r'[^a-zA-Z0-9_-]', '-', a['name']) or 'agent'
    return FileResponse(dest, filename=f'Orbit-{safe_name}-Backup.zip', background=BackgroundTask(dest.unlink, missing_ok=True))


@app.get('/api/export/project')
async def export_project():
    p = HERE.parent.parent / 'Orbit-Desktop-Agent.zip'
    if not p.is_file():
        raise HTTPException(404, 'The source ZIP is not packaged yet. Use Arena Workspace → Download instead.')
    return FileResponse(p, filename=p.name, media_type='application/zip')


@app.websocket('/ws/desktop')
async def desktop_stream(websocket: WebSocket):
    if auth.REQUIRED and not auth.valid_session(websocket.cookies.get(auth.COOKIE, '')):
        await websocket.close(code=1008)
        return
    origin = websocket.headers.get('origin')
    hosts = {websocket.headers.get('host'), websocket.headers.get('x-forwarded-host')}
    if origin and urlparse(origin).netloc not in hosts:
        await websocket.close(code=1008)
        return
    await websocket.accept()
    try:
        while True:
            if runtime.desktop_ready:
                image = await asyncio.to_thread(capture_screen)
                await websocket.send_bytes(image)
            else:
                await websocket.send_json({'starting': True})
            await asyncio.sleep(.2)
    except Exception:
        # Disconnects and display teardown stop this stream; never emit a private traceback.
        pass


@app.get('/app')
async def workbench():
    return FileResponse(HERE / 'static/index.html')


@app.get('/guide')
async def improvement_guide():
    return FileResponse(HERE / 'static/guide.html')


@app.get('/api/site')
async def site_info():
    s = runtime.status()
    return {'product': 'Orbit', 'version': '3.1', 'engine_ready': s['engine_ready'], 'phase': s['phase'],
            'model': s['model'], 'vision': s['vision'], 'context': s['context'], 'local_inference': True,
            'external_ai_api': False, 'existing_pretrained_weights': True, 'desktop_type': s['desktop_type'],
            'knowledge_retrieval': 'Local SQLite FTS5', 'saved_project_limit_mb': storage.LIMIT // 1_000_000,
            'development_session': True}


@app.get('/api/knowledge')
async def knowledge_list(agent: str):
    checked_agent(agent)
    return {'documents': knowledge.documents(agent), 'summary': knowledge.summary(agent)}


@app.post('/api/knowledge/upload')
async def knowledge_upload(agent: str = Form(...), file: UploadFile = File(...)):
    checked_agent(agent)
    content = await file.read(knowledge.MAX_FILE + 1)
    name = file.filename or ''
    await file.close()
    return await asyncio.to_thread(knowledge.index_document, agent, name, content)


@app.get('/api/knowledge/search')
async def knowledge_search(agent: str, q: str):
    checked_agent(agent)
    if len(q) > 1200:
        raise HTTPException(400, 'Keep search queries under 1200 characters')
    return {'hits': knowledge.search(agent, q)}


@app.get('/api/knowledge/{document_id}/download')
async def knowledge_download(document_id: str, agent: str):
    checked_agent(agent)
    d = knowledge.get_document(agent, document_id)
    p = store.safe_path(agent, d['path'])
    if not p.is_file():
        raise HTTPException(404, 'The original source file is missing')
    return FileResponse(p, filename=d['name'], media_type='application/octet-stream')


@app.delete('/api/knowledge/{document_id}')
async def knowledge_remove(document_id: str, agent: str):
    checked_agent(agent)
    if runtime.active_task and not runtime.manual:
        raise HTTPException(409, 'Let the current task finish before removing a source')
    knowledge.remove_document(agent, document_id)
    return {'ok': True}


class FeedbackInput(BaseModel):
    agent: str
    message: str = Field(max_length=32)
    score: int
    correction: str = Field(default='', max_length=2000)


@app.post('/api/feedback')
async def answer_feedback(body: FeedbackInput):
    checked_agent(body.agent)
    return knowledge.save_feedback(body.agent, body.message, body.score, body.correction)


@app.get('/api/feedback/export')
async def export_feedback(agent: str):
    import json
    from fastapi.responses import StreamingResponse
    checked_agent(agent)
    def lines():
        with store.connect() as db:
            rows = db.execute('''SELECT f.*,m.content AS answer FROM answer_feedback f
                LEFT JOIN messages m ON m.id=f.message AND m.agent=f.agent
                WHERE f.agent=? ORDER BY f.created''', (agent,))
            for row in rows:
                yield (json.dumps(dict(row), ensure_ascii=False) + '\n').encode()
    return StreamingResponse(lines(), media_type='application/x-ndjson', headers={'Content-Disposition': 'attachment; filename="Orbit-feedback.ndjson"'})


@app.middleware('http')
async def owner_access(request: Request, call_next):
    if auth.REQUIRED and not (auth.public_request(request) or auth.authenticated(request) or auth.desktop_bridge(request)):
        if request.url.path == '/app' and request.method == 'GET':
            from fastapi.responses import RedirectResponse
            return RedirectResponse('/login', status_code=303)
        return JSONResponse({'detail': 'Owner login required.'}, status_code=401, headers={'Cache-Control': 'no-store'})
    response = await call_next(request)
    if request.url.path.startswith('/api/') or request.url.path in {'/app', '/login'}:
        response.headers['Cache-Control'] = 'no-store'
    if auth.REQUIRED and request.url.path in {'/app', '/login'}:
        response.headers['Content-Security-Policy'] = "frame-ancestors 'self'"
    return response


@app.get('/login')
async def login_page():
    return FileResponse(HERE / 'static/login.html')


@app.get('/api/auth/status')
async def auth_status(request: Request):
    return {'required': auth.REQUIRED, 'configured': auth.configured(), 'authenticated': auth.authenticated(request)}


class LoginInput(BaseModel):
    password: str = Field(min_length=1, max_length=512)


@app.post('/api/auth/login')
async def login(request: Request, body: LoginInput):
    if not auth.REQUIRED:
        return {'ok': True, 'required': False}
    if not auth.configured():
        raise HTTPException(503, 'The host has not configured owner login. Run create_auth.py on the host first.')
    key = request.client.host if request.client else 'unknown'
    if not auth.login_allowed(key):
        raise HTTPException(429, 'Too many login attempts. Try again in ten minutes.')
    valid = await asyncio.to_thread(auth.verify_password, body.password)
    if not valid:
        raise HTTPException(401, 'Incorrect password.')
    auth.clear_attempts(key)
    response = JSONResponse({'ok': True})
    response.set_cookie(auth.COOKIE, auth.issue_session(), max_age=auth.TTL, httponly=True,
                        secure=os.environ.get('ORBIT_COOKIE_SECURE', '1') != '0', samesite='lax', path='/')
    return response


@app.post('/api/auth/logout')
async def logout():
    response = JSONResponse({'ok': True})
    response.delete_cookie(auth.COOKIE, path='/')
    return response
