"""Small, durable single-user store. No credentials or model traces are stored."""
import sqlite3
import time
import uuid
from pathlib import Path
import json
from . import storage

ROOT = Path(__file__).resolve().parent.parent
WORKSPACE = ROOT / 'workspace'
WORKSPACE.mkdir(exist_ok=True)
DB = WORKSPACE / '.orbit.sqlite'


def connect():
    db = sqlite3.connect(DB)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA journal_mode=WAL')
    return db


def init():
    with connect() as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS agents(id TEXT PRIMARY KEY, name TEXT, role TEXT, color TEXT, created REAL);
        CREATE TABLE IF NOT EXISTS messages(id TEXT PRIMARY KEY, agent TEXT, role TEXT, content TEXT, created REAL);
        CREATE TABLE IF NOT EXISTS tasks(id TEXT PRIMARY KEY, agent TEXT, prompt TEXT, state TEXT, result TEXT, created REAL, finished REAL);
        CREATE TABLE IF NOT EXISTS events(id TEXT PRIMARY KEY, agent TEXT, task TEXT, kind TEXT, label TEXT, detail TEXT, state TEXT, created REAL);
        CREATE TABLE IF NOT EXISTS preferences(key TEXT PRIMARY KEY, value TEXT);
        ''')
        if 'memory' not in [r[1] for r in db.execute('PRAGMA table_info(agents)')]:
            db.execute("ALTER TABLE agents ADD COLUMN memory TEXT NOT NULL DEFAULT ''")
        db.execute("UPDATE tasks SET state='interrupted', result='The runtime restarted before this task finished.' WHERE state IN ('queued','running','waiting','paused')")
    if not agents():
        a = add_agent('Orbit', 'A thoughtful general-purpose agent. Research, write, and work carefully on your own computer.', 'sage')
        message(a['id'], 'assistant', "I’m Orbit, your local desktop agent. Give me a task and watch me work on the computer next to this conversation.\n\nI can read websites, create and read files, and run approved terminal commands. I use a small local AI model—not Grok—and important results should be checked.")
        (agent_dir(a['id']) / 'START-HERE.md').write_text('# Welcome to your agent’s computer\n\nThis is a real Linux sandbox with Chromium, a filesystem, and a terminal.\n\nOrbit uses an existing open-weight model running locally; the current configuration is shown in model details. No external AI API or key is used. Website visits still use the internet.\n\nTry asking it to create a checklist, read a webpage, or run `ls -la`.\n\nFile access is limited by the app to this agent’s workspace. Terminal tools are allowlisted and require approval when requested by the agent. This single-user development server is not a hardened production deployment.\n', encoding='utf-8')


def agents():
    with connect() as db:
        return [dict(r) for r in db.execute('SELECT * FROM agents ORDER BY created')]


def agent(agent_id):
    with connect() as db:
        r = db.execute('SELECT * FROM agents WHERE id=?', (agent_id,)).fetchone()
    if not r:
        raise ValueError('Agent not found')
    return dict(r)


def add_agent(name, role, color='sage'):
    a = dict(id=uuid.uuid4().hex, name=name.strip()[:32], role=role.strip()[:500], color=color, created=time.time())
    if not a['name']:
        raise ValueError('Give your agent a name')
    storage.require(16000)
    a['memory'] = ''
    with connect() as db:
        db.execute('INSERT INTO agents(id,name,role,color,created,memory) VALUES(:id,:name,:role,:color,:created,:memory)', a)
    agent_dir(a['id']).mkdir(exist_ok=True)
    return a


def agent_dir(agent_id):
    if not agent_id or any(c not in '0123456789abcdef' for c in agent_id) or len(agent_id) != 32:
        raise ValueError('Invalid agent identifier')
    p = WORKSPACE / agent_id
    p.mkdir(exist_ok=True)
    return p


def message(agent_id, role, content):
    storage.require(len(content.encode()) + 8192, refresh=False)
    m = dict(id=uuid.uuid4().hex, agent=agent_id, role=role, content=content, created=time.time())
    with connect() as db:
        db.execute('INSERT INTO messages VALUES(:id,:agent,:role,:content,:created)', m)
    return m


def messages(agent_id):
    with connect() as db:
        return [dict(r) for r in db.execute('SELECT * FROM messages WHERE agent=? ORDER BY created', (agent_id,)).fetchall()[-120:]]


def new_task(agent_id, prompt):
    t = dict(id=uuid.uuid4().hex, agent=agent_id, prompt=prompt, state='queued', result='', created=time.time(), finished=None)
    with connect() as db:
        db.execute('INSERT INTO tasks VALUES(:id,:agent,:prompt,:state,:result,:created,:finished)', t)
    return t


def task_state(task_id, state, result=None):
    with connect() as db:
        if result is None:
            db.execute('UPDATE tasks SET state=? WHERE id=?', (state, task_id))
        else:
            db.execute('UPDATE tasks SET state=?,result=?,finished=? WHERE id=?', (state, result, time.time(), task_id))


def tasks(agent_id=None):
    with connect() as db:
        if agent_id:
            rows = db.execute('SELECT * FROM tasks WHERE agent=? ORDER BY created DESC LIMIT 30', (agent_id,))
        else:
            rows = db.execute('SELECT * FROM tasks ORDER BY created DESC LIMIT 60')
        return [dict(r) for r in rows]


def event(agent_id, task_id, kind, label, detail='', state='done'):
    e = dict(id=uuid.uuid4().hex, agent=agent_id, task=task_id or '', kind=kind, label=label, detail=str(detail)[:12000], state=state, created=time.time())
    with connect() as db:
        db.execute('INSERT INTO events VALUES(:id,:agent,:task,:kind,:label,:detail,:state,:created)', e)
    return e['id']


def event_update(event_id, state, detail=None):
    with connect() as db:
        if detail is None:
            db.execute('UPDATE events SET state=? WHERE id=?', (state, event_id))
        else:
            db.execute('UPDATE events SET state=?,detail=? WHERE id=?', (state, str(detail)[:12000], event_id))


def events(agent_id=None):
    with connect() as db:
        if agent_id:
            rows = db.execute('SELECT * FROM events WHERE agent=? ORDER BY created DESC LIMIT 120', (agent_id,))
        else:
            rows = db.execute('SELECT * FROM events ORDER BY created DESC LIMIT 120')
        return [dict(r) for r in rows]


def safe_path(agent_id, filename):
    root = agent_dir(agent_id).resolve()
    if not filename or '\x00' in filename or Path(filename).is_absolute():
        raise ValueError('Use a relative filename in the agent workspace')
    path = (root / filename).resolve()
    if path == root or root not in path.parents or any(s.startswith('.') for s in Path(filename).parts):
        raise ValueError('That path is outside the allowed workspace')
    return path


def files(agent_id):
    root = agent_dir(agent_id)
    result = []
    for p in sorted(root.rglob('*')):
        if p.is_file() and not p.is_symlink() and not any(s.startswith('.') for s in p.relative_to(root).parts):
            s = p.stat()
            result.append(dict(name=str(p.relative_to(root)), size=s.st_size, modified=s.st_mtime))
    return result[:150]


def update_agent(agent_id, **values):
    agent(agent_id)
    limits = {'name': 32, 'role': 500, 'memory': 2000}
    for key, value in values.items():
        if key not in limits:
            raise ValueError('Unknown agent preference')
        if key == 'name' and not str(value).strip():
            raise ValueError('Give the agent a name')
        with connect() as db:
            db.execute(f'UPDATE agents SET {key}=? WHERE id=?', (str(value).strip()[:limits[key]], agent_id))
    return agent(agent_id)


def preference(key, default=None):
    with connect() as db:
        row = db.execute('SELECT value FROM preferences WHERE key=?', (key,)).fetchone()
    return json.loads(row['value']) if row else default


def set_preference(key, value):
    with connect() as db:
        db.execute('INSERT OR REPLACE INTO preferences(key,value) VALUES(?,?)', (key, json.dumps(value)))
