#!/usr/bin/env python3
"""Run interactively on your OWN host. Never send the password in chat.
Stores a salted hash and signing key in an ignored, mode-0600 environment file.
"""
import getpass
import os
import secrets
from pathlib import Path
from shlex import quote
from app.auth import password_hash


def main():
    target = Path('.orbit-owner.env')
    if target.exists():
        answer = input('Replace owner credentials and invalidate existing sessions? [y/N] ').strip().lower()
        if answer != 'y':
            print('Nothing changed.')
            return
    first = getpass.getpass('Choose a long owner passphrase (12+ characters): ')
    if not 12 <= len(first) <= 512:
        raise SystemExit('Use 12–512 characters. Nothing was written.')
    second = getpass.getpass('Repeat the passphrase: ')
    if first != second:
        raise SystemExit('Passphrases did not match. Nothing was written.')
    values = {'ORBIT_AUTH_REQUIRED': '1', 'ORBIT_PASSWORD_HASH': password_hash(first),
              'ORBIT_SESSION_SECRET': secrets.token_urlsafe(48), 'ORBIT_COOKIE_SECURE': '1'}
    content = '# Private owner configuration. NEVER commit or share this file.\n' + ''.join(k + '=' + quote(v) + '\n' for k,v in values.items())
    fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    os.fchmod(fd, 0o600)
    with os.fdopen(fd, 'w') as f:
        f.write(content)
    target.chmod(0o600)
    print('Owner login configured. Password was not stored in plaintext.')
    print('Start with: bash public_start.sh')


if __name__ == '__main__':
    main()
